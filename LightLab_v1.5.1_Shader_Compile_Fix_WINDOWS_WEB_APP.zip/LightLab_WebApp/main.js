/* LightLab v1.5.1 GLSL Reserved Keyword Fix + Capture: depth-averaged water and dielectric path tracing.
   NOT a converged 3D Navier-Stokes or spectral caustic solver.
   LightLab v1.1: self-contained WebGL2 progressive path tracer.
   Model assets are processed from the three user-supplied FBX files.
   Physics: radiometric path transport, sampled area emitters, diffuse GGX/Smith
   microfacet surfaces, Schlick Fresnel, recursive throughput and Russian roulette.
   Lamp glass: approximate thin-tinted transmission, not spectral wave optics.
*/
'use strict';

const $ = (id) => document.getElementById(id);
const canvas = $('viewport');
const state = {
  room: true, lamp: true, orb: false, power: 55, exposure: .85,
  orbPos: [0, 1.85, .7],
  noiseFilter: true, waterVisible: false,
  quality: 'balanced',
  lastNonPerformanceMode: 'balanced', autoBalance: true, motionPreview: true,
  dynamicScale: 1, movingPreview: false,
  samples: 0,
  yaw: .60, pitch: .29, radius: 3.68, target: [0, .80, -.04],
  dragging: false, dragMode: null, prevX: 0, prevY: 0,
  redraw: true, waterFocus:true,
  captureActive:false, captureReady:false, captureTargetSamples:512, captureStartSample:0, captureSaved:false,
  captureRestore:null, captureCompleted:false, captureStartedAt:0
};
const qualityModes = LightLabQuality.MODES;
let gl, meta, traceProgram, displayProgram, guideProgram, triTexture, bvhTexture, deskColor, deskRough, deskNormal, brassColor, brassRough;
let quadVAO, textures=[], fbos=[], currentBuffer=0, renderW=0, renderH=0;
let uniforms={}, displayUniforms={}, guideUniforms={}, guideTextures=[], guideFBO=null, guideReady=false, extFloat=false, running=false, currentFrame=0;
let lastDisplayTime=0, toastTimeout, linearHalfFloat=true;
const telemetry={uiFrames:0,displayFrames:0,traceFrames:0,physicsSeconds:0,hadPhysics:false,
  periodStart:0,lastTraceAt:-1000, gpuExtension:null, pendingGpu:null,
  lastGpuQueryAt:-1000, lastScaleChangeAt:0, lastGpuMs:NaN};
const fluid=new LightLabFluid.FluidStudy();
let waterTexture,filmTexture,waterLastTime=0,lastPhysicsFrame=0,waterMovingUntil=0,waterDrops=new Float32Array(64*4);

function toast(message){const t=$('toast');t.textContent=message;t.classList.add('visible');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>t.classList.remove('visible'),2700);}
function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
function normalize(a){let l=Math.hypot(...a);return a.map(v=>v/(l||1));}
function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function sub(a,b){return a.map((x,i)=>x-b[i]);}
function add(a,b){return a.map((x,i)=>x+b[i]);}
function mul(a,s){return a.map(x=>x*s);}
function dot(a,b){return a.reduce((acc,x,i)=>acc+x*b[i],0);}
function cameraBasis(){
  const {yaw,pitch,radius,target}=state;
  const position=[target[0]+radius*Math.sin(yaw)*Math.cos(pitch),target[1]+radius*Math.sin(pitch),target[2]+radius*Math.cos(yaw)*Math.cos(pitch)];
  const forward=normalize(sub(target,position));const right=normalize(cross(forward,[0,1,0]));const up=normalize(cross(right,forward));
  return{position,forward,right,up};
}
function invalidate(){state.samples=0;state.redraw=true;guideReady=false;}
function saveCanvasPNG(name='LightLab-render-capture.png'){
  // Invoked by a direct user click; a completed capture remains visible until resumed.
  if(!state.captureActive) return;
  renderDisplay();
  const a=document.createElement('a');
  a.download=name;
  a.href=canvas.toDataURL('image/png');
  document.body.appendChild(a);a.click();a.remove();
  state.captureSaved=true;toast('PNG export requested');
}
function updateCaptureUI(){
  const el=$('capture-status'),btn=$('capture'),save=$('capture-save');
  if(!el||!btn)return;
  document.body.classList.toggle('capture-busy',state.captureActive);
  el.classList.remove('active','done');
  save.disabled=!state.captureActive;
  $('capture-quality').disabled=state.captureActive;
  if(state.captureActive){
    const done=Math.max(0,state.samples-state.captureStartSample);
    const need=state.captureTargetSamples;
    const elapsed=Math.floor((performance.now()-state.captureStartedAt)/1000);
    if(state.captureReady){
      el.classList.add('done');el.textContent=`READY · ${done} SPP · ${elapsed}s · SAVE PNG`;
      btn.innerHTML='↩ <span>RETURN TO LIVE</span>';
      $('renderer-state').textContent='FROZEN CAPTURE READY';
    }else{
      el.classList.add('active');el.textContent=`CAPTURING · ${done} / ${need} SPP · ${elapsed}s`;
      btn.innerHTML='✕ <span>CANCEL / RETURN TO LIVE</span>';
      $('renderer-state').textContent='CAPTURE IN PROGRESS';
    }
    btn.title=state.captureReady?'Return to the interactive scene':'Cancel and return to interactive scene';
  }else{
    el.textContent=state.captureCompleted?'RETURNED TO LIVE · CAPTURE CLOSED':'IDLE';
    btn.innerHTML='⌗ <span>RENDER CAPTURE</span>';
    btn.title='Freeze camera, water and lights; progressively render an unfiltered still';
  }
}
function cancelCapture(){
  if(!state.captureActive)return;
  const restore=state.captureRestore;
  state.captureActive=false;state.captureReady=false;state.captureCompleted=true;
  state.captureRestore=null;
  if(restore){
    fluid.paused=restore.fluidPaused;
    state.noiseFilter=restore.noiseFilter;
    state.autoBalance=restore.autoBalance;
    state.motionPreview=restore.motionPreview;
    state.dynamicScale=1;
    $('filter-toggle').checked=state.noiseFilter;
    if(state.quality!==restore.quality)setMode(restore.quality);
    else{resize();invalidate();updateModeUI();}
  }
  updateWaterUI();updateCaptureUI();
}
function startCapture(){
  if(state.captureActive){cancelCapture();toast('Returned to interactive scene');return;}
  state.captureCompleted=false;state.captureSaved=false;state.captureReady=false;
  state.captureRestore={quality:state.quality,fluidPaused:fluid.paused,noiseFilter:state.noiseFilter,autoBalance:state.autoBalance,motionPreview:state.motionPreview};
  const selected=Number($('capture-quality').value);
  state.captureTargetSamples=Number.isFinite(selected)?selected:512;
  state.captureActive=true;state.captureStartSample=0;state.captureStartedAt=performance.now();
  fluid.paused=true;state.noiseFilter=false;state.autoBalance=false;state.motionPreview=false;state.dynamicScale=1;
  $('filter-toggle').checked=false;
  if(state.quality!=='reference')setMode('reference');else{resize();invalidate();updateModeUI();}
  updateWaterUI();updateCaptureUI();
  toast('Scene frozen · unfiltered reference rays accumulating');
}
function showLoad(s){$('load-message').textContent=s;}
function shader(type,source){const sh=gl.createShader(type);gl.shaderSource(sh,source);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error('Shader compilation: '+gl.getShaderInfoLog(sh));return sh;}
function program(vertex,fragment){const p=gl.createProgram();const v=shader(gl.VERTEX_SHADER,vertex),f=shader(gl.FRAGMENT_SHADER,fragment);gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('Shader linking: '+gl.getProgramInfoLog(p));gl.deleteShader(v);gl.deleteShader(f);return p;}
const vertexShader=`#version 300 es
precision highp float;
layout(location=0) in vec2 aPosition;
out vec2 vUv;
void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}
`;
const traceShader=`#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
in vec2 vUv;
layout(location=0) out vec4 fragColor;
#define PI 3.14159265358979323846
#define EPS 0.0006
#define MAT_COUNT 22
#define MAX_BOUNCES 12
uniform sampler2D uTriangles;
uniform sampler2D uBVH;
uniform sampler2D uDeskColor;
uniform sampler2D uDeskRough;
uniform sampler2D uDeskNormal;
uniform sampler2D uBrassColor;
uniform sampler2D uBrassRough;
uniform sampler2D uPrevious;
uniform ivec2 uTriSize;
uniform ivec2 uBvhSize;
uniform vec2 uResolution;
uniform vec3 uCamera;
uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform float uTanFov;
uniform float uLensShift;
uniform float uAspect;
uniform int uFrame;
uniform int uBounces;
uniform int uSppPerPass;
uniform bool uRoom;
uniform bool uLamp;
uniform bool uOrb;
uniform float uOrbPower;
uniform vec3 uOrbPos;
uniform vec4 uMaterialA[MAT_COUNT];
uniform vec4 uMaterialB[MAT_COUNT];
// Water prototype: surface heights, tabletop film, and explicitly conserved parcel volumes.
uniform sampler2D uWaterHeight;
uniform sampler2D uDeskFilm;
uniform vec3 uCupPos;
uniform vec2 uCupTilt;
uniform vec4 uDrops[64];
uniform int uDropCount;
uniform float uCupFill;
uniform bool uWaterEnabled;
uniform float uSampleClamp;
const float WATER_R=.037;
const float GLASS_R=.040;
const float GLASS_HEIGHT=.112;
const float WATER_DEPTH=.108;
const float DESK_HEIGHT=.767;

uvec3 randomState;
float rand(){randomState=randomState*1664525u+1013904223u;randomState.x+=randomState.y*randomState.z;randomState.y+=randomState.z*randomState.x;randomState.z+=randomState.x*randomState.y;return float(randomState.x^randomState.y^randomState.z)* (1.0/4294967296.0);}
vec3 randSphere(){float z=rand()*2.-1.;float phi=rand()*2.*PI;float r=sqrt(max(0.,1.-z*z));return vec3(r*cos(phi),z,r*sin(phi));}
vec4 readTex(sampler2D tex,ivec2 size,int idx){return texelFetch(tex,ivec2(idx%size.x,idx/size.x),0);}
struct Ray{vec3 o;vec3 d;};
struct Hit{float t;vec3 p;vec3 n;vec2 uv;vec3 tangent;vec3 bitangent;int mat;};
Hit miss(){Hit h;h.t=1e20;h.p=vec3(0);h.n=vec3(0,1,0);h.uv=vec2(0);h.tangent=vec3(1,0,0);h.bitangent=vec3(0,0,1);h.mat=-1;return h;}
// Two-sided triangle intersection, with smooth vertex normals interpolated on hit.
void triangleHit(Ray ray,int id,inout Hit best){
  int start=id*7;
  vec4 t0=readTex(uTriangles,uTriSize,start);
  vec4 t1=readTex(uTriangles,uTriSize,start+1);
  vec4 t2=readTex(uTriangles,uTriSize,start+2);
  vec3 pv=cross(ray.d,t2.xyz);
  float determinant=dot(t1.xyz,pv);
  if(abs(determinant)<1e-9)return;
  float inv=1./determinant;
  vec3 tv=ray.o-t0.xyz;
  float u=dot(tv,pv)*inv;
  if(u<0.||u>1.)return;
  vec3 q=cross(tv,t1.xyz);
  float v=dot(ray.d,q)*inv;
  if(v<0.||u+v>1.)return;
  float t=dot(t2.xyz,q)*inv;
  if(t<EPS||t>=best.t)return;
  vec4 n0=readTex(uTriangles,uTriSize,start+3);
  vec4 n1=readTex(uTriangles,uTriSize,start+4);
  vec4 n2=readTex(uTriangles,uTriSize,start+5);
  vec4 tail=readTex(uTriangles,uTriSize,start+6);
  vec3 normal=n0.xyz*(1.-u-v)+n1.xyz*u+n2.xyz*v;
  if(dot(normal,normal)<.2)normal=cross(t1.xyz,t2.xyz);
  normal=normalize(normal);
  best.t=t;best.p=ray.o+ray.d*t;best.n=normal;best.mat=int(t0.w+.5);
  vec2 uv0=vec2(t1.w,t2.w),uv1=vec2(n0.w,n1.w),uv2=vec2(n2.w,tail.x);
  best.uv=uv0*(1.-u-v)+uv1*u+uv2*v;
  if(best.mat==0){
    vec2 du1=uv1-uv0,du2=uv2-uv0;
    float den=du1.x*du2.y-du2.x*du1.y;
    if(abs(den)>1e-8){best.tangent=normalize((t1.xyz*du2.y-t2.xyz*du1.y)/den);best.bitangent=normalize((t2.xyz*du1.x-t1.xyz*du2.x)/den);}
    else{best.tangent=vec3(1,0,0);best.bitangent=vec3(0,0,1);}
  }
}
// Texture-driven binary bounding volume hierarchy. Materials and geometry are unbaked.
void intersectMesh(Ray ray,inout Hit hit){
  vec3 invDir=1./(ray.d+sign(ray.d)*1e-9+vec3(1e-15));
  int stack[40];int ptr=0;stack[ptr++]=0;
  for(int step=0;step<512;step++){
    if(ptr<=0)break;
    int index=stack[--ptr];
    vec4 a=readTex(uBVH,uBvhSize,index*2);
    vec4 b=readTex(uBVH,uBvhSize,index*2+1);
    vec3 tA=(a.xyz-ray.o)*invDir;vec3 tB=(b.xyz-ray.o)*invDir;
    vec3 tmin=min(tA,tB),tmax=max(tA,tB);
    float nearT=max(max(tmin.x,tmin.y),tmin.z);
    float farT=min(min(tmax.x,tmax.y),tmax.z);
    if(farT<max(EPS,nearT)||nearT>hit.t)continue;
    int left=int(a.w);
    if(left<0){int start=-left-1;int count=int(b.w);for(int i=0;i<6;i++){if(i>=count)break;triangleHit(ray,start+i,hit);}}
    else{if(ptr<38){stack[ptr++]=int(b.w);stack[ptr++]=left;}}
  }
}
void intersectSphere(Ray ray,vec3 pos,float radius,int mat,inout Hit hit){
  vec3 oc=ray.o-pos;float b=dot(oc,ray.d);float c=dot(oc,oc)-radius*radius;
  float discriminant=b*b-c;
  if(discriminant<0.)return;
  float s=sqrt(discriminant);float t=-b-s;
  if(t<EPS)t=-b+s;
  if(t<EPS||t>=hit.t)return;
  hit.t=t;hit.p=ray.o+ray.d*t;hit.n=normalize(hit.p-pos);hit.uv=vec2(0);hit.mat=mat;hit.tangent=vec3(1,0,0);hit.bitangent=vec3(0,0,1);
}
void intersectPanel(Ray ray,vec3 center,vec2 ext,int mat,inout Hit hit){
  if(abs(ray.d.y)<1e-6)return;
  float t=(center.y-ray.o.y)/ray.d.y;
  if(t<EPS||t>=hit.t)return;
  vec3 p=ray.o+ray.d*t;
  if(abs(p.x-center.x)>ext.x||abs(p.z-center.z)>ext.y)return;
  hit.t=t;hit.p=p;hit.n=vec3(0,-1,0);hit.uv=vec2(0);hit.mat=mat;hit.tangent=vec3(1,0,0);hit.bitangent=vec3(0,0,1);
}
// Rotationally symmetric cup in true SI units. Intersection is performed in
// its moving local frame, with actual 3 mm glass thickness and an open rim.
vec3 cupToWorld(vec3 q){float cx=cos(uCupTilt.x),sx=sin(uCupTilt.x),cz=cos(uCupTilt.y),sz=sin(uCupTilt.y);
  vec3 a=vec3(q.x,cx*q.y-sx*q.z,sx*q.y+cx*q.z);
  return vec3(cz*a.x-sz*a.y,sz*a.x+cz*a.y,a.z)+uCupPos;
}
vec3 worldToCupVector(vec3 q){float cx=cos(uCupTilt.x),sx=sin(uCupTilt.x),cz=cos(uCupTilt.y),sz=sin(uCupTilt.y);
  vec3 a=vec3(cz*q.x+sz*q.y,-sz*q.x+cz*q.y,q.z);
  return vec3(a.x,cx*a.y+sx*a.z,-sx*a.y+cx*a.z);
}
vec3 cupToWorldVector(vec3 q){return cupToWorld(q)-uCupPos;}
float waterDepthAt(vec2 xz){vec2 uv=clamp(xz/(2.*WATER_R)+.5,vec2(0),vec2(1));return texture(uWaterHeight,uv).r;}
float filmDepthAt(vec2 xz){vec2 uv=(xz-vec2(-1.08,-.507))/vec2(2.16,1.014);
 if(any(lessThan(uv,vec2(0)))||any(greaterThan(uv,vec2(1))))return 0.;
 return texture(uDeskFilm,uv).r;
}
void cupCandidate(Ray ray,vec3 op,vec3 dir,float t,vec3 n,int mat,inout Hit best){
 if(t<EPS*.12||t>=best.t)return;
 best.t=t;best.p=ray.o+t*ray.d;best.n=normalize(cupToWorldVector(n));best.uv=vec2(0);best.mat=mat;
 best.tangent=vec3(1,0,0);best.bitangent=vec3(0,0,1);
}
void intersectCup(Ray ray,inout Hit hit){
 vec3 ro=worldToCupVector(ray.o-uCupPos),rd=worldToCupVector(ray.d);
 float aa=dot(rd.xz,rd.xz),b=dot(ro.xz,rd.xz);
 if(aa>1e-12){
   for(int side=0;side<2;side++){
     float radius=side==0?GLASS_R:WATER_R;
     float discriminant=b*b-aa*(dot(ro.xz,ro.xz)-radius*radius);
     if(discriminant<0.)continue;
     float sr=sqrt(discriminant);
     for(int k=0;k<2;k++){
       float t=(-b+(k==0?-sr:sr))/aa;
       float y=ro.y+rd.y*t;
       if(y<.004||y>GLASS_HEIGHT||t<=0.)continue;
       // Outward normal of the glass solid on the inner face points into cavity.
       vec3 n=vec3(ro.x+rd.x*t,0.,ro.z+rd.z*t)/radius;
       cupCandidate(ray,ro,rd,t,side==0?n:-n,25,hit);
     }
   }
 }
 if(abs(rd.y)>1e-9){
   for(int k=0;k<3;k++){
     float h=k==0?0.:(k==1?.004:GLASS_HEIGHT),t=(h-ro.y)/rd.y;
     vec2 q=ro.xz+rd.xz*t;
     float r2=dot(q,q);
     if(k==0&&r2<=GLASS_R*GLASS_R)cupCandidate(ray,ro,rd,t,vec3(0,-1,0),25,hit);
     if(k==1&&r2<=WATER_R*WATER_R)cupCandidate(ray,ro,rd,t,vec3(0,1,0),25,hit);
     if(k==2&&r2>=WATER_R*WATER_R&&r2<=GLASS_R*GLASS_R)cupCandidate(ray,ro,rd,t,vec3(0,1,0),25,hit);
   }
 }
 // Water is a separate volume, bounded by glass and a dynamic free surface.
 // Intersect actual heightfield rather than imposing animated sine waves.
 if(abs(rd.y)>.000001){
   float t=(.004+uCupFill-ro.y)/rd.y;
   for(int i=0;i<5;i++){
     vec3 q=ro+rd*t;
     float h=.004+waterDepthAt(q.xz);
     t+=(h-q.y)/rd.y;
   }
   vec3 q=ro+rd*t;
   if(dot(q.xz,q.xz)<WATER_R*WATER_R&&q.y>=.003&&q.y<GLASS_HEIGHT+.07){
     float e=.0018;
     float dhdx=(waterDepthAt(q.xz+vec2(e,0))-waterDepthAt(q.xz-vec2(e,0)))/(2.*e);
     float dhdz=(waterDepthAt(q.xz+vec2(0,e))-waterDepthAt(q.xz-vec2(0,e)))/(2.*e);
     cupCandidate(ray,ro,rd,t,normalize(vec3(-dhdx,1.,-dhdz)),26,hit);
   }
 }
}
void intersectWaterDrops(Ray ray,inout Hit hit){
 for(int i=0;i<64;i++){if(i>=uDropCount)break;
   vec4 d=uDrops[i];if(d.w<.00001)continue;
   intersectSphere(ray,d.xyz,d.w,27,hit);
 }
}
void intersectDeskFilm(Ray ray,inout Hit hit){
 if(abs(ray.d.y)<.00001)return;
 float t=(DESK_HEIGHT+.002-ray.o.y)/ray.d.y;
 for(int i=0;i<4;i++){
   vec3 p=ray.o+ray.d*t;
   float thickness=filmDepthAt(p.xz);
   t+=(DESK_HEIGHT+thickness-p.y)/ray.d.y;
 }
 if(t<=EPS*.12||t>=hit.t)return;
 vec3 p=ray.o+ray.d*t;
 float depth=filmDepthAt(p.xz);
 if(depth<.000002||abs(p.y-DESK_HEIGHT-depth)>.0006)return;
 float e=.01;
 float dx=(filmDepthAt(p.xz+vec2(e,0))-filmDepthAt(p.xz-vec2(e,0)))/(2.*e);
 float dz=(filmDepthAt(p.xz+vec2(0,e))-filmDepthAt(p.xz-vec2(0,e)))/(2.*e);
 hit.t=t;hit.p=p;hit.n=normalize(vec3(-dx,1,-dz));hit.mat=28;hit.uv=vec2(0);hit.tangent=vec3(1,0,0);hit.bitangent=vec3(0,0,1);
}
// Exact nonabsorbing Fresnel dielectric reflectance of an unpolarized ray.
float fresnelDielectric(float cosI,float etaI,float etaT){
 cosI=clamp(abs(cosI),0.,1.);
 float sinT2=(etaI/etaT)*(etaI/etaT)*max(0.,1.-cosI*cosI);
 if(sinT2>=1.)return 1.;
 float cosT=sqrt(max(0.,1.-sinT2));
 float rs=(etaI*cosI-etaT*cosT)/(etaI*cosI+etaT*cosT);
 float rp=(etaT*cosI-etaI*cosT)/(etaT*cosI+etaI*cosT);
 return .5*(rs*rs+rp*rp);
}
Hit intersectScene(Ray ray){
  Hit hit=miss();intersectMesh(ray,hit);
  if(uWaterEnabled){intersectCup(ray,hit);intersectWaterDrops(ray,hit);intersectDeskFilm(ray,hit);}
  intersectSphere(ray,vec3(-.557,1.221,-.110),.032,uLamp?22:19,hit);
  if(uOrb)intersectSphere(ray,uOrbPos,.044,23,hit);
  intersectPanel(ray,vec3(-.92,3.173,.08),vec2(.48,.34),uRoom?24:19,hit);
  intersectPanel(ray,vec3(.92,3.173,.08),vec2(.48,.34),uRoom?24:19,hit);
  return hit;
}
vec3 baseColor(Hit h){
  if(h.mat>=25&&h.mat<=28)return h.mat==25?vec3(.95,.96,.97):vec3(.94,.98,1.);
  if(h.mat==0){vec3 c=texture(uDeskColor,vec2(h.uv.x,1.-h.uv.y)).rgb;return max(c,vec3(.005));}
  if(h.mat==1||h.mat==3){vec2 texUV=h.p.xz*3.1+vec2(h.p.y*.6,h.p.y*.3);vec3 texColor=texture(uBrassColor,texUV).rgb;return mix(uMaterialA[h.mat].xyz,texColor,.26);}
  if(h.mat==16){float grain=sin(h.p.x*66.+sin(h.p.z*9.)*1.5)*.035+sin(h.p.x*13.+h.p.z*17.)*.023;return vec3(.23,.129,.075)*(1.+grain);}
  if(h.mat==15){float n=sin(h.p.x*43.)*sin(h.p.y*29.)*.012;return vec3(.44,.42,.39)+n;}
  if(h.mat>=0&&h.mat<MAT_COUNT)return uMaterialA[h.mat].xyz;
  return vec3(.8);
}
float surfaceRoughness(Hit h){
  if(h.mat==0){float tex=texture(uDeskRough,vec2(h.uv.x,1.-h.uv.y)).r;return clamp(mix(.26,.83,tex),.09,.96);}
  if(h.mat==1||h.mat==3){float r=texture(uBrassRough,h.p.xz*3.1+vec2(h.p.y*.6,h.p.y*.3)).r;return clamp(mix(uMaterialA[h.mat].w,.62,r*.32),.05,.7);}
  if(h.mat>=0&&h.mat<MAT_COUNT)return uMaterialA[h.mat].w;
  return .4;
}
float surfaceMetallic(int mat){return mat>=0&&mat<MAT_COUNT?uMaterialB[mat].x:0.;}
float surfaceTransmission(int mat){return mat>=0&&mat<MAT_COUNT?uMaterialB[mat].y:0.;}
vec3 emission(int mat){
  if(mat==22&&uLamp)return vec3(240.,144.,64.);
  if(mat==23&&uOrb)return vec3(100.,111.,122.)*uOrbPower*.01;
  if(mat==24&&uRoom)return vec3(18.,20.,23.);
  return vec3(0);
}
float ggxD(float NdotH,float alpha){float a2=alpha*alpha;float denom=NdotH*NdotH*(a2-1.)+1.;return a2/(PI*denom*denom+1e-8);}
float G1(float NdotV,float a){float a2=a*a;return 2.*NdotV/(NdotV+sqrt(a2+(1.-a2)*NdotV*NdotV)+1e-8);}
vec3 fresnel(vec3 f0,float dotHV){return f0+(vec3(1)-f0)*pow(clamp(1.-dotHV,0.,1.),5.);}
vec3 evaluateBRDF(vec3 base,float metallic,float rough,vec3 n,vec3 v,vec3 l){
  float NdotL=max(dot(n,l),0.),NdotV=max(dot(n,v),0.);
  if(NdotL<=0.||NdotV<=0.)return vec3(0);
  vec3 h=normalize(v+l);
  float NdotH=max(dot(n,h),0.),VdotH=max(dot(v,h),0.);
  float a=max(.004,rough*rough);
  vec3 F=fresnel(mix(vec3(.04),base,metallic),VdotH);
  float D=ggxD(NdotH,a), G=G1(NdotV,a)*G1(NdotL,a);
  vec3 spec=F*(D*G/(4.*NdotV*NdotL+1e-7));
  vec3 diffuse=(vec3(1)-F)*(1.-metallic)*base/PI;
  return diffuse+spec;
}
float sampleWeight(vec3 base,float metallic){return clamp(mix(.28,.85,metallic)+max(max(base.r,base.g),base.b)*metallic*.08,.1,.95);}
vec3 tangentSpace(vec3 n,vec3 s){vec3 t=normalize(cross(abs(n.y)<.98?vec3(0,1,0):vec3(1,0,0),n));vec3 b=cross(n,t);return t*s.x+b*s.y+n*s.z;}
// Heitz visible-normal GGX sampling avoids extreme NDF-sampling weights at grazing angles.
// PDF of reflected outgoing direction: D(h)*G1(v)/(4*|n.v|).
float bsdfPdf(vec3 n,vec3 v,vec3 l,float rough,float specWeight){
  float ndl=max(dot(n,l),0.),ndv=max(dot(n,v),0.);
  if(ndl<=0.||ndv<=0.)return 0.;
  vec3 h=normalize(v+l);
  float ndh=max(dot(n,h),0.),vdh=dot(v,h);
  if(vdh<=0.)return 0.;
  float a=max(.004,rough*rough);
  float pd=ndl/PI;
  float ps=ggxD(ndh,a)*G1(ndv,a)/(4.*ndv);
  return mix(pd,ps,specWeight);
}
vec3 sampleVisibleGGX(vec3 n,vec3 v,float a){
  vec3 t=normalize(cross(abs(n.y)<.99?vec3(0.,1.,0.):vec3(1.,0.,0.),n));
  vec3 b=cross(n,t);
  vec3 vl=vec3(dot(v,t),dot(v,b),max(.00001,dot(v,n)));
  vec3 vh=normalize(vec3(a*vl.x,a*vl.y,vl.z));
  float len2=vh.x*vh.x+vh.y*vh.y;
  vec3 t1=len2>1e-9?vec3(-vh.y,vh.x,0.)*inversesqrt(len2):vec3(1.,0.,0.);
  vec3 t2=cross(vh,t1);
  float r=sqrt(rand()),phi=2.*PI*rand();
  float x=r*cos(phi),y=r*sin(phi);
  float s=.5*(1.+vh.z);
  y=mix(sqrt(max(0.,1.-x*x)),y,s);
  vec3 nh=x*t1+y*t2+sqrt(max(0.,1.-x*x-y*y))*vh;
  vec3 hl=normalize(vec3(a*nh.x,a*nh.y,max(0.,nh.z)));
  vec3 h=normalize(t*hl.x+b*hl.y+n*hl.z);
  return reflect(-v,h);
}
vec3 sampleBRDF(vec3 n,vec3 v,float rough,float specWeight){
  if(rand()<specWeight)return sampleVisibleGGX(n,v,max(.004,rough*rough));
  float u=rand(),v1=rand(),phi=2.*PI*u,r=sqrt(v1);
  return normalize(tangentSpace(n,vec3(r*cos(phi),r*sin(phi),sqrt(max(0.,1.-v1)))));
}
int activeLights(){return (uLamp?1:0)+(uOrb&&uOrbPower>0.?1:0)+(uRoom?2:0);}
// Area (not point) light sources create physically soft penumbras.
void pickLight(int k,out vec3 p,out vec3 n,out vec3 Le,out float area){
  int i=k;
  if(uLamp){if(i==0){vec3 center=vec3(-.557,1.221,-.110);n=randSphere();p=center+n*.032;Le=vec3(240.,144.,64.);area=4.*PI*.032*.032;return;}i--;}
  if(uOrb&&uOrbPower>0.){if(i==0){n=randSphere();p=uOrbPos+n*.044;Le=vec3(100.,111.,122.)*uOrbPower*.01;area=4.*PI*.044*.044;return;}i--;}
  n=vec3(0,-1,0);area=.96*.68;Le=vec3(18.,20.,23.);
  p=vec3(i==0?-.92:.92,3.173,.08)+vec3((rand()-.5)*.96,0.,(rand()-.5)*.68);
}
// Shadow-connection estimator for explicit transmitting surfaces.  A sampled
// straight light path is not the full refractive caustic solution: refracted
// interfaces bend rays.  Here we evaluate Fresnel interface transmission and
// Beer--Lambert segment attenuation under a THIN, NEAR-PARALLEL LAYER
// approximation.  The specular camera paths below still obey Snell's law.
// Unlike v1.3, clear water and glass are NOT treated as opaque blockers.
vec3 visibility(vec3 p,vec3 lightPoint,vec3 normal){
  vec3 delta=lightPoint-p;
  float fullLength=length(delta);
  if(fullLength<.0001)return vec3(0.);
  vec3 direction=delta/fullLength;
  Ray sr;sr.d=direction;sr.o=p+normal*EPS*3.;
  float remaining=dot(lightPoint-sr.o,direction);
  vec3 tr=vec3(1.);
  int medium=0;
  bool complete=false;
  for(int i=0;i<16;i++){
    if(remaining<=EPS*8.){complete=true;break;}
    Hit occ=intersectScene(sr);
    float segment=min(occ.t,remaining);
    // Spectral approximations for clear water and common soda-lime glass.
    vec3 absorb=medium==2?vec3(.09,.037,.016):(medium==1?vec3(.10,.055,.025):vec3(0.));
    tr*=exp(-absorb*max(segment,0.));
    if(occ.t>=remaining-EPS*8.){complete=true;break;}
    if(occ.mat==4){
      // v1.3 shade is modeled as a thin dyed screen; retained unchanged.
      tr*=vec3(.54,.85,.60);
    }else if(occ.mat==28){
      // Thin desk film: transmit toward the desk instead of trapping the ray in a
      // thick opaque-looking water layer. This improves puddle reflections and
      // prevents the dark circular shadow artifact seen in v1.4.
      vec3 gn=normalize(occ.n);
      float F=fresnelDielectric(dot(direction,gn),1.,1.333);
      float thickness=max(filmDepthAt(occ.p.xz),0.00002);
      tr*=exp(-vec3(.09,.037,.016)*thickness)*(1.-F);
      sr.o=occ.p+direction*max(thickness*1.25,EPS*4.);
      remaining=dot(lightPoint-sr.o,direction);
      continue;
    }else if(occ.mat>=25&&occ.mat<=27){
      float etaI=medium==1?1.52:(medium==2?1.333:1.);
      int nextMedium=0;
      vec3 gn=normalize(occ.n);
      bool entering=dot(direction,gn)<0.;
      if(occ.mat==25){
        vec3 q=worldToCupVector(occ.p-uCupPos);
        bool inner=(abs(length(q.xz)-WATER_R)<.0007&&q.y>.003);
        bool under=(q.y<=.004+waterDepthAt(q.xz));
        nextMedium=entering?1:((inner&&under)?2:0);
      }else{
        nextMedium=entering?2:0;
      }
      float etaT=nextMedium==1?1.52:(nextMedium==2?1.333:1.);
      float F=fresnelDielectric(dot(direction,gn),etaI,etaT);
      tr*=1.-F;
      medium=nextMedium;
    }else{
      return vec3(0.);
    }
    if(max(max(tr.x,tr.y),tr.z)<.000001)return vec3(0.);
    sr.o=occ.p+direction*EPS*.9;
    remaining=dot(lightPoint-sr.o,direction);
  }
  // If a ray exhausted the interface budget, don't invent visibility.
  return complete?tr:vec3(0.);
}
// A primary-visible surface samples every active emitter once for stable direct light.
// Secondary bounces sample one emitter, with an appropriately matched MIS PDF.
vec3 directLightOne(Hit h,vec3 n,vec3 v,vec3 base,float rough,float metal,int choice,bool allLights){
  int count=activeLights();if(count<=0)return vec3(0);
  vec3 lp,ln,Le;float area;pickLight(choice,lp,ln,Le,area);
  vec3 delta=lp-h.p;float distance2=dot(delta,delta);float distance=sqrt(distance2);
  vec3 l=delta/distance;
  float nl=max(dot(n,l),0.),lcos=max(dot(ln,-l),0.);
  if(nl<=0.||lcos<=0.)return vec3(0);
  vec3 trans=visibility(h.p,lp,n);
  if(max(max(trans.x,trans.y),trans.z)<.0001)return vec3(0);
  // Area PDF transformed to the solid angle at the receiving surface.
  float pdf=distance2/(area*lcos)*(allLights?1.:1./float(count));
  vec3 brdf=evaluateBRDF(base,metal,rough,n,v,l);
  float w=sampleWeight(base,metal);
  float bsPdf=bsdfPdf(n,v,l,rough,w);
  float mis=pdf*pdf/(pdf*pdf+bsPdf*bsPdf+1e-7);
  return Le*trans*brdf*nl*mis/max(pdf,1e-6);
}
vec3 directLight(Hit h,vec3 n,vec3 v,vec3 base,float rough,float metal,int bounce){
  int count=activeLights();if(count<=0)return vec3(0);
  if(bounce<=1){
    vec3 sum=vec3(0);
    for(int i=0;i<4;i++){if(i>=count)break;sum+=directLightOne(h,n,v,base,rough,metal,i,true);}
    return sum;
  }
  int choice=min(count-1,int(floor(rand()*float(count))));
  return directLightOne(h,n,v,base,rough,metal,choice,false);
}
vec3 radiance(Ray ray){
  vec3 throughput=vec3(1.);vec3 result=vec3(0.);int medium=0;
  bool prevDelta=true;bool prevSampledAll=false;float prevPdf=1.;vec3 prevPoint=ray.o;
  for(int bounce=0;bounce<MAX_BOUNCES;bounce++){
    if(bounce>=uBounces)break;
    Hit hit=intersectScene(ray);
    if(hit.mat>=0){
      // Beer-Lambert extinction. Clear 20°C water has weak visible absorption
      // over ~8cm; clear glass is weakly absorbing across 3mm wall thickness.
      vec3 absorption=medium==2?vec3(.09,.037,.016):(medium==1?vec3(.10,.055,.025):vec3(0));
      throughput*=exp(-absorption*hit.t);
    }
    if(hit.mat<0){break;} // Zero environment radiance: no invented ambient light.
    vec3 emitted=emission(hit.mat);
    if(hit.mat==24&&dot(hit.n,-ray.d)<=0.)emitted=vec3(0.); // One-sided ceiling emitters.
    if(max(max(emitted.x,emitted.y),emitted.z)>0.){
      float weight=1.;
      if(bounce>0&&!prevDelta){
        int nLights=activeLights();
        float area=hit.mat==22?4.*PI*.032*.032:hit.mat==23?4.*PI*.044*.044:.96*.68;
        vec3 ld=hit.p-prevPoint;float dist2=dot(ld,ld);
        float lightCos=max(dot(normalize(hit.n),-normalize(ld)),0.);
        float lightPdf=dist2/max(area*lightCos,1e-8)*(prevSampledAll?1.:1./float(max(nLights,1)));
        weight=prevPdf*prevPdf/(prevPdf*prevPdf+lightPdf*lightPdf+1e-7);
      }
      result+=throughput*emitted*weight;
      break;
    }
    if(hit.mat==28){
      // A real wet desk is a thin transparent interface above an opaque wood
      // substrate. Sample exact dielectric Fresnel reflection probability;
      // a transmitted ray must reach the substrate rather than jumping beyond
      // it by the global ray epsilon (which previously made puddles go black).
      vec3 filmN=normalize(hit.n);
      if(dot(ray.d,filmN)>0.)filmN=-filmN;
      float F=fresnelDielectric(dot(ray.d,filmN),1.,1.333);
      float thickness=max(filmDepthAt(hit.p.xz),0.000002);
      if(rand()<F){
        ray.d=reflect(ray.d,filmN);prevDelta=true;
        ray.o=hit.p+ray.d*EPS*.25;continue;
      }
      // The probability of choosing transmission is already 1-F. Its
      // contribution has probability weight one; do not multiply by 1-F again.
      float pathLength=thickness/max(abs(dot(ray.d,filmN)),.05);
      throughput*=exp(-vec3(.09,.037,.016)*pathLength);
      Hit substrate=miss();
      intersectMesh(ray,substrate);
      if(substrate.mat<0||substrate.t<=hit.t)break;
      hit=substrate; // Shade the actual desk underneath the film this bounce.
    }
    vec3 n=normalize(hit.n);if(dot(n,ray.d)>0.)n=-n;
    if(hit.mat==0){
      vec3 tangent=normalize(hit.tangent-n*dot(n,hit.tangent));
      vec3 bitangent=normalize(hit.bitangent-n*dot(n,hit.bitangent));
      vec3 tn=texture(uDeskNormal,vec2(hit.uv.x,1.-hit.uv.y)).xyz*2.-1.;
      n=normalize(n*max(.2,tn.z)+tangent*tn.x*.55+bitangent*tn.y*.55);
      if(dot(n,ray.d)>0.)n=-n;
    }
    vec3 v=-ray.d;
    if(hit.mat>=25&&hit.mat<=27){
      vec3 geometricN=normalize(hit.n);
      bool entering=dot(ray.d,geometricN)<0.;
      float etaI=medium==1?1.52:(medium==2?1.333:1.0);
      int nextMedium=0;
      if(hit.mat==25){
        // Outer / inner glass boundaries; determine inner fluid from local height.
        vec3 q=worldToCupVector(hit.p-uCupPos);
        bool innerBoundary=(abs(length(q.xz)-WATER_R)<.0007&&q.y>.003);
        bool underWater=(q.y<=.004+waterDepthAt(q.xz));
        if(entering)nextMedium=1;
        else nextMedium=(innerBoundary&&underWater)?2:0;
      }else if(hit.mat==26){nextMedium=entering?2:0;}
      else if(hit.mat==27){nextMedium=entering?2:0;}
      else{nextMedium=entering?2:0;}
      float etaT=nextMedium==1?1.52:(nextMedium==2?1.333:1.);
      // Handle cavity water-to-glass transitions and internal solid interfaces.
      float F=fresnelDielectric(dot(ray.d,geometricN),etaI,etaT);
      vec3 n=entering?geometricN:-geometricN;
      if(rand()<F){ray.d=reflect(ray.d,n);}
      else{
        vec3 refracted=refract(ray.d,n,etaI/etaT);
        if(dot(refracted,refracted)<.0001){ray.d=reflect(ray.d,n);}
        else {ray.d=normalize(refracted);throughput*=pow(etaI/etaT,2.);medium=nextMedium;}
      }
      prevDelta=true;ray.o=hit.p+ray.d*EPS*.25;
      continue;
    }
    if(hit.mat==4){
      float fr=.035+.965*pow(1.-max(dot(n,v),0.),5.);
      if(rand()<fr){ray.d=reflect(ray.d,n);throughput*=vec3(.94,.98,.95);prevDelta=true;}
      else{throughput*=vec3(.80,.95,.81);prevDelta=true;}
      ray.o=hit.p+ray.d*EPS*3.;continue;
    }
    vec3 base=baseColor(hit);
    float rough=surfaceRoughness(hit),metal=surfaceMetallic(hit.mat);
    result+=throughput*directLight(hit,n,v,base,rough,metal,bounce);
    float specWeight=sampleWeight(base,metal);
    vec3 next=sampleBRDF(n,v,rough,specWeight);
    float cosine=max(dot(n,next),0.);
    if(cosine<=0.)break;
    float pdf=bsdfPdf(n,v,next,rough,specWeight);
    if(pdf<1e-8)break;
    vec3 brdf=evaluateBRDF(base,metal,rough,n,v,next);
    throughput*=brdf*cosine/pdf;
    prevDelta=false;prevSampledAll=(bounce<=1);prevPdf=pdf;prevPoint=hit.p;
    if(bounce>=2){float survive=clamp(max(max(throughput.r,throughput.g),throughput.b),.12,.91);if(rand()>survive)break;throughput/=survive;}
    ray.o=hit.p+n*EPS*3.;ray.d=next;
  }
  return result; // No firefly-clamping bias in the integrated radiance.
}
void main(){
  uvec2 pixel=uvec2(gl_FragCoord.xy);
  vec3 batch=vec3(0.);
  for(int i=0;i<4;i++){
    if(i>=uSppPerPass)break;
    uint seed=uint(uFrame+i+1);
    randomState=uvec3(pixel.x*1973u+seed*9277u+7u,pixel.y*26699u+seed*6271u+113u,seed*1699u+317u);
    rand();rand();rand();
    vec2 jitter=vec2(rand(),rand())-.5;
    vec2 ndc=((gl_FragCoord.xy+jitter)/uResolution*2.-1.);
    ndc.x=ndc.x*uAspect+uLensShift;
    Ray ray;ray.o=uCamera;
    ray.d=normalize(uForward+uRight*(ndc.x*uTanFov)+uUp*(ndc.y*uTanFov));
    vec3 pathRadianceSample=radiance(ray);
    float peak=max(max(pathRadianceSample.r,pathRadianceSample.g),pathRadianceSample.b);
    if(uSampleClamp>0.&&peak>uSampleClamp)pathRadianceSample*=uSampleClamp/peak;
    batch+=pathRadianceSample;
  }
  vec3 prev=uFrame>0?texelFetch(uPrevious,ivec2(gl_FragCoord.xy),0).rgb:vec3(0.);
  float total=float(uFrame+uSppPerPass);
  fragColor=vec4((prev*float(uFrame)+batch)/total,1.);
}
`;
// Guide pass intersects the same geometry without random jitter. It is never used
// to modify accumulated radiance; it only prevents display denoising across edges.
const guideShader=traceShader.replace(
  'layout(location=0) out vec4 fragColor;',
  'layout(location=0) out vec4 fragColor;\nlayout(location=1) out vec4 fragGuideMaterial;'
).replace(/void main\(\)\{[\s\S]*\}\s*$/, `void main(){
  vec2 ndc=(gl_FragCoord.xy/uResolution*2.-1.);
  ndc.x=ndc.x*uAspect+uLensShift;
  Ray ray;ray.o=uCamera;
  ray.d=normalize(uForward+uRight*ndc.x*uTanFov+uUp*ndc.y*uTanFov);
  Hit h=intersectScene(ray);
  if(h.mat<0){fragColor=vec4(0.,0.,0.,1e12);fragGuideMaterial=vec4(0.,0.,0.,-1.);return;}
  vec3 n=normalize(h.n);
  if(dot(n,ray.d)>0.)n=-n;
  fragColor=vec4(n*.5+.5,h.t);
  fragGuideMaterial=vec4(baseColor(h),float(h.mat));
}`);
const displayShader=`#version 300 es
precision highp float;
in vec2 vUv;
layout(location=0) out vec4 fragColor;
uniform sampler2D uTexture;
uniform sampler2D uGuideGeom;
uniform sampler2D uGuideMaterial;
uniform vec2 uTraceSize;
uniform float uExposure;
uniform bool uDenoise;
uniform int uSamples;
float luminance(vec3 c){return dot(c,vec3(.2126,.7152,.0722));}
vec3 filtered(vec2 uv){
  vec3 c=max(texture(uTexture,uv).rgb,vec3(0.));
  if(!uDenoise||uSamples>=96)return c;
  vec4 cg=texture(uGuideGeom,uv),cm=texture(uGuideMaterial,uv);
  if(cm.a<0.)return c;
  // Optional display-only, linear-radiance bilateral preview. No logarithmic
  // averaging that systematically darkens isolated high-energy samples.
  // The unfiltered reference can always be selected; the accumulation is raw.
  vec2 px=1./uTraceSize;
  vec3 sum=vec3(0.);float weight=0.;
  for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){
    vec2 p=uv+vec2(float(x),float(y))*px;
    vec4 g=texture(uGuideGeom,p),m=texture(uGuideMaterial,p);
    if(abs(m.a-cm.a)>.25)continue;
    float normalAgree=dot(g.rgb*2.-1.,cg.rgb*2.-1.);
    if(normalAgree<.96)continue;
    if(abs(g.a-cg.a)>max(.007,cg.a*.005))continue;
    float w=exp(-float(x*x+y*y)*.8)*exp(-length(m.rgb-cm.rgb)*6.);
    sum+=max(texture(uTexture,p).rgb,vec3(0.))*w;
    weight+=w;
  }
  vec3 preview=sum/max(weight,1e-7);
  float t=smoothstep(12.,96.,float(uSamples));
  return mix(preview,c,t);
}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
vec3 srgbEncode(vec3 x){return mix(12.92*x,1.055*pow(max(x,vec3(0.)),vec3(1./2.4))-.055,step(vec3(.0031308),x));}
void main(){
  vec3 linear=max(filtered(vUv),vec3(0.))*uExposure;
  fragColor=vec4(srgbEncode(aces(linear)),1.);
}
`;

function fluidTex(width,height){
 const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,linearHalfFloat?gl.LINEAR:gl.NEAREST);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,linearHalfFloat?gl.LINEAR:gl.NEAREST);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,width,height,0,gl.RGBA,gl.FLOAT,null);
 gl.bindTexture(gl.TEXTURE_2D,null);return t;
}
function uploadFluid(){
 gl.bindTexture(gl.TEXTURE_2D,waterTexture);
 gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,fluid.N,fluid.N,gl.RGBA,gl.FLOAT,fluid.getWaterTexture());
 gl.bindTexture(gl.TEXTURE_2D,filmTexture);
 gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,fluid.fw,fluid.fh,gl.RGBA,gl.FLOAT,fluid.getFilmTexture());
 gl.bindTexture(gl.TEXTURE_2D,null);
 waterDrops=fluid.renderDrops(64);
}
function fluidUniforms(u){
 bindUnit(8,waterTexture);bindUnit(9,filmTexture);
 gl.uniform1i(u.uWaterHeight,8);gl.uniform1i(u.uDeskFilm,9);
 gl.uniform3fv(u.uCupPos,fluid.cupPos);gl.uniform2fv(u.uCupTilt,fluid.angles);
 gl.uniform4fv(u['uDrops[0]'],waterDrops);gl.uniform1i(u.uDropCount,fluid.drops.length);
 gl.uniform1f(u.uCupFill,fluid.P.innerHeight*.75);
 gl.uniform1i(u.uWaterEnabled,state.waterVisible?1:0);
}
function updateWaterStats(){
 const l=fluid.ledger(),ml=x=>(x*1e6).toFixed(1);
 $('cup-water').textContent=ml(l.cup)+' mL';$('desk-water').textContent=ml(l.desk)+' mL';
 $('flight-water').textContent=ml(l.flight)+' mL';$('floor-water').textContent=ml(l.floor)+' mL';
 $('initial-water').textContent=ml(l.initial)+' mL';
 $('mass-error').textContent=ml(l.error)+' mL';
 $('drop-count').textContent=String(fluid.drops.length);
 $('water-status').textContent=!state.waterVisible?'HIDDEN':fluid.paused?'PAUSED':'SIMULATING';
}
function makeDataTexture(bin,texelsPerEntry,entryCount){
  const width=1024,height=Math.ceil(entryCount*texelsPerEntry/width);
  const arr=new Float32Array(width*height*4);
  arr.set(new Float32Array(bin));
  const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,width,height,0,gl.RGBA,gl.FLOAT,arr);
  gl.bindTexture(gl.TEXTURE_2D,null);
  return{tex,width,height};
}
function loadImageTexture(url,isSRGB){
  return new Promise((resolve,reject)=>{
    const image=new Image();image.onload=()=>{
      const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
      gl.texImage2D(gl.TEXTURE_2D,0,isSRGB?gl.SRGB8_ALPHA8:gl.RGBA,image.width,image.height,0,gl.RGBA,gl.UNSIGNED_BYTE,image);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
      gl.generateMipmap(gl.TEXTURE_2D);resolve(tex);
    };image.onerror=()=>reject(Error('Could not load texture '+url));image.src=url;
  });
}
function loc(p,n){return gl.getUniformLocation(p,n);}
function bindUnit(unit,tex){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,tex);}
function setUniforms(programObject,names){return Object.fromEntries(names.map(name=>[name,loc(programObject,name)]));}
function setupRenderer(){
  gl=canvas.getContext('webgl2',{alpha:false,depth:false,antialias:false,preserveDrawingBuffer:true,powerPreference:'high-performance',desynchronized:true});
  if(!gl)throw Error('WebGL 2 is required. Enable hardware acceleration in your browser.');
  extFloat=!!gl.getExtension('EXT_color_buffer_float');
  telemetry.gpuExtension=gl.getExtension('EXT_disjoint_timer_query_webgl2');
  linearHalfFloat=!!gl.getExtension('OES_texture_float_linear');
  if(!extFloat)throw Error('Floating-point render targets are not available (EXT_color_buffer_float).');
  gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
  // Render floating point fluid surface heights, not a visual ripple animation.
  waterTexture=fluidTex(fluid.N,fluid.N);filmTexture=fluidTex(fluid.fw,fluid.fh);
  uploadFluid();
  traceProgram=program(vertexShader,traceShader);guideProgram=program(vertexShader,guideShader);displayProgram=program(vertexShader,displayShader);
  quadVAO=gl.createVertexArray();gl.bindVertexArray(quadVAO);
  const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);gl.bindVertexArray(null);
  uniforms=setUniforms(traceProgram,['uTriangles','uBVH','uDeskColor','uDeskRough','uDeskNormal','uBrassColor','uBrassRough','uPrevious','uTriSize','uBvhSize','uResolution','uCamera','uForward','uRight','uUp','uTanFov','uLensShift','uAspect','uFrame','uBounces','uSppPerPass','uRoom','uLamp','uOrb','uOrbPower','uOrbPos','uMaterialA[0]','uMaterialB[0]','uWaterHeight','uDeskFilm','uCupPos','uCupTilt','uDrops[0]','uDropCount','uCupFill','uWaterEnabled','uSampleClamp']);
  guideUniforms=setUniforms(guideProgram,['uTriangles','uBVH','uDeskColor','uBrassColor','uTriSize','uBvhSize','uResolution','uCamera','uForward','uRight','uUp','uTanFov','uLensShift','uAspect','uRoom','uLamp','uOrb','uOrbPos','uMaterialA[0]','uWaterHeight','uDeskFilm','uCupPos','uCupTilt','uDrops[0]','uDropCount','uCupFill','uWaterEnabled','uSampleClamp']);
  displayUniforms=setUniforms(displayProgram,['uTexture','uGuideGeom','uGuideMaterial','uTraceSize','uExposure','uDenoise','uSamples']);
}
function resize(){
  const d=LightLabQuality.dimensions(window.innerWidth,window.innerHeight,window.devicePixelRatio,
    state.quality,state.dynamicScale,state.movingPreview);
  if(canvas.width!==d.canvasW)canvas.width=d.canvasW;
  if(canvas.height!==d.canvasH)canvas.height=d.canvasH;
  const {width:w,height:h}=d;
  if(renderW===w&&renderH===h)return;
  renderW=w;renderH=h;
  textures.forEach(t=>gl.deleteTexture(t));fbos.forEach(f=>gl.deleteFramebuffer(f));guideTextures.forEach(t=>gl.deleteTexture(t));if(guideFBO)gl.deleteFramebuffer(guideFBO);textures=[];fbos=[];guideTextures=[];guideFBO=null;
  for(let i=0;i<2;i++){
    const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,linearHalfFloat?gl.LINEAR:gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,linearHalfFloat?gl.LINEAR:gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,w,h,0,gl.RGBA,gl.FLOAT,null);
    const fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
    const status=gl.checkFramebufferStatus(gl.FRAMEBUFFER);if(status!==gl.FRAMEBUFFER_COMPLETE)throw Error('Framebuffer could not be allocated ('+status+').');
    textures.push(tex);fbos.push(fb);
  }
  guideFBO=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,guideFBO);
  for(let i=0;i<2;i++){
    const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,w,h,0,gl.RGBA,gl.FLOAT,null);
    gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0+i,gl.TEXTURE_2D,tex,0);
    guideTextures.push(tex);
  }
  gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);
  if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Guide framebuffer allocation failed');
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);invalidate();currentBuffer=0;
  if($('render-resolution'))$('render-resolution').textContent=w+' × '+h;
}
function renderGuide(){
  const b=cameraBasis();gl.useProgram(guideProgram);gl.bindVertexArray(quadVAO);
  gl.bindFramebuffer(gl.FRAMEBUFFER,guideFBO);gl.drawBuffers([gl.COLOR_ATTACHMENT0,gl.COLOR_ATTACHMENT1]);gl.viewport(0,0,renderW,renderH);
  bindUnit(0,triTexture.tex);bindUnit(1,bvhTexture.tex);bindUnit(2,deskColor);bindUnit(5,brassColor);
  for(const [name,i] of [['uTriangles',0],['uBVH',1],['uDeskColor',2],['uBrassColor',5]])gl.uniform1i(guideUniforms[name],i);
  gl.uniform2i(guideUniforms.uTriSize,triTexture.width,triTexture.height);gl.uniform2i(guideUniforms.uBvhSize,bvhTexture.width,bvhTexture.height);
  gl.uniform2f(guideUniforms.uResolution,renderW,renderH);
  gl.uniform3fv(guideUniforms.uCamera,b.position);gl.uniform3fv(guideUniforms.uForward,b.forward);gl.uniform3fv(guideUniforms.uRight,b.right);gl.uniform3fv(guideUniforms.uUp,b.up);
  gl.uniform1f(guideUniforms.uTanFov,Math.tan(48*Math.PI/360));gl.uniform1f(guideUniforms.uLensShift,.16);gl.uniform1f(guideUniforms.uAspect,renderW/renderH);
  gl.uniform1i(guideUniforms.uRoom,state.room?1:0);gl.uniform1i(guideUniforms.uLamp,state.lamp?1:0);gl.uniform1i(guideUniforms.uOrb,state.orb?1:0);
  gl.uniform3fv(guideUniforms.uOrbPos,state.orbPos);
  fluidUniforms(guideUniforms);
  const a=[];for(const m of meta.materials)a.push(...m.color,m.roughness);
  gl.uniform4fv(guideUniforms['uMaterialA[0]'],a);
  gl.drawArrays(gl.TRIANGLES,0,6);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindVertexArray(null);guideReady=true;
}
function renderTrace(){
  const b=cameraBasis();gl.useProgram(traceProgram);gl.bindVertexArray(quadVAO);
  const target=currentBuffer;const previous=1-currentBuffer;
  gl.bindFramebuffer(gl.FRAMEBUFFER,fbos[target]);gl.viewport(0,0,renderW,renderH);
  bindUnit(0,triTexture.tex);bindUnit(1,bvhTexture.tex);bindUnit(2,deskColor);bindUnit(3,deskRough);bindUnit(4,deskNormal);bindUnit(5,brassColor);bindUnit(6,brassRough);bindUnit(7,textures[previous]);
  for(const [name,i] of [['uTriangles',0],['uBVH',1],['uDeskColor',2],['uDeskRough',3],['uDeskNormal',4],['uBrassColor',5],['uBrassRough',6],['uPrevious',7]])gl.uniform1i(uniforms[name],i);
  gl.uniform2i(uniforms.uTriSize,triTexture.width,triTexture.height);gl.uniform2i(uniforms.uBvhSize,bvhTexture.width,bvhTexture.height);
  gl.uniform2f(uniforms.uResolution,renderW,renderH);
  gl.uniform3fv(uniforms.uCamera,b.position);gl.uniform3fv(uniforms.uForward,b.forward);gl.uniform3fv(uniforms.uRight,b.right);gl.uniform3fv(uniforms.uUp,b.up);
  gl.uniform1f(uniforms.uTanFov,Math.tan(48*Math.PI/360));gl.uniform1f(uniforms.uLensShift,.16);
  gl.uniform1f(uniforms.uAspect,renderW/renderH);
  const sppPerPass=state.samples===0?qualityModes[state.quality].firstPassSpp:1;
  gl.uniform1i(uniforms.uFrame,state.samples);gl.uniform1i(uniforms.uSppPerPass,sppPerPass);
  gl.uniform1i(uniforms.uBounces,qualityModes[state.quality].bounces);
  gl.uniform1i(uniforms.uRoom,state.room?1:0);gl.uniform1i(uniforms.uLamp,state.lamp?1:0);gl.uniform1i(uniforms.uOrb,state.orb?1:0);
  gl.uniform1f(uniforms.uOrbPower,state.power);gl.uniform3fv(uniforms.uOrbPos,state.orbPos);
  const sampleClamp=state.quality==='performance'&&!state.captureActive?22:0; // Balance/reference accumulate unclamped radiance.
  gl.uniform1f(uniforms.uSampleClamp,sampleClamp);
  fluidUniforms(uniforms);
  const a=[],bb=[];for(const m of meta.materials){a.push(...m.color,m.roughness);bb.push(m.metallic,m.transmission,m.emission,0);}
  gl.uniform4fv(uniforms['uMaterialA[0]'],a);gl.uniform4fv(uniforms['uMaterialB[0]'],bb);
  gl.drawArrays(gl.TRIANGLES,0,6);
  gl.bindVertexArray(null);currentBuffer=previous;
  state.samples+=sppPerPass;telemetry.traceFrames++;
}
function renderDisplay(){
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.useProgram(displayProgram);gl.bindVertexArray(quadVAO);
  bindUnit(0,textures[1-currentBuffer]);gl.uniform1i(displayUniforms.uTexture,0);
  bindUnit(1,guideTextures[0]);gl.uniform1i(displayUniforms.uGuideGeom,1);
  bindUnit(2,guideTextures[1]);gl.uniform1i(displayUniforms.uGuideMaterial,2);
  gl.uniform2f(displayUniforms.uTraceSize,renderW,renderH);gl.uniform1f(displayUniforms.uExposure,state.exposure);
  gl.uniform1i(displayUniforms.uDenoise,(state.noiseFilter&&state.quality!=='reference')?1:0);gl.uniform1i(displayUniforms.uSamples,state.samples);
  gl.drawArrays(gl.TRIANGLES,0,6);gl.bindVertexArray(null);
  telemetry.displayFrames++;
}
function updateModeUI(){
 const m=qualityModes[state.quality];
 document.querySelectorAll('[data-quality]').forEach(b=>{
   const active=b.dataset.quality===state.quality;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));
 });
 $('quality-note').textContent=m.description;
 $('mode-explanation').textContent=m.limitation+' Water discretization remains identical across modes; no mass is reset.';
 $('mode-readout').textContent=m.label;
 $('auto-balance').disabled=!m.autoAdjust;
 $('auto-balance').checked=state.autoBalance && m.autoAdjust;
 $('motion-preview').checked=state.motionPreview;
 $('quick-mode').setAttribute('aria-pressed',String(state.quality==='performance'));
 $('quick-mode').textContent=state.quality==='performance'?'RESTORE '+state.lastNonPerformanceMode.toUpperCase():'QUICK PERFORMANCE';
 $('gpu-timing').textContent=telemetry.gpuExtension?'Measuring…':'Unavailable (fixed scale)';
}
function setMode(name){
 if(!qualityModes[name] || name===state.quality)return;
 if(state.quality!=='performance')state.lastNonPerformanceMode=state.quality;
 state.quality=name;state.dynamicScale=1;telemetry.lastScaleChangeAt=performance.now();
 // Intentionally do NOT construct/reset LightLabFluid, modify water arrays,
 // restore the cup, toggle lights, or change source intensities.
 resize();invalidate();updateModeUI();
 toast(qualityModes[name].label+' · fluid state preserved');
}
function setMovingPreview(active){
 const next=Boolean(active&&state.motionPreview&&state.quality!=='reference');
 if(next===state.movingPreview)return;
 state.movingPreview=next;resize();invalidate();
}
function beginGpuSample(t){
 const ext=telemetry.gpuExtension;
 if(!ext||telemetry.pendingGpu||t-telemetry.lastGpuQueryAt<950)return false;
 const q=gl.createQuery();gl.beginQuery(ext.TIME_ELAPSED_EXT,q);
 telemetry.pendingGpu={query:q,mode:state.quality,width:renderW,height:renderH};
 telemetry.lastGpuQueryAt=t;return true;
}
function pollGpuSample(t){
 const ext=telemetry.gpuExtension,p=telemetry.pendingGpu;
 if(!ext||!p)return;
 if(gl.getParameter(ext.GPU_DISJOINT_EXT)){
   gl.deleteQuery(p.query);telemetry.pendingGpu=null;return;
 }
 if(!gl.getQueryParameter(p.query,gl.QUERY_RESULT_AVAILABLE))return;
 const ms=gl.getQueryParameter(p.query,gl.QUERY_RESULT)*1e-6;
 gl.deleteQuery(p.query);telemetry.pendingGpu=null;
 if(p.mode!==state.quality||p.width!==renderW||p.height!==renderH)return;
 telemetry.lastGpuMs=ms;
 $('gpu-timing').textContent=ms.toFixed(1)+' ms / trace';
 const m=qualityModes[state.quality];
 if(!state.autoBalance||!m.autoAdjust||state.dragging||state.movingPreview||t-telemetry.lastScaleChangeAt<2600)return;
 const goal=m.targetGpuMs;let next=state.dynamicScale;
 if(ms>goal*1.28)next*=Math.max(.78,Math.sqrt(goal/ms));
 else if(ms<goal*.60)next*=1.075;
 next=clamp(next,m.minScale/m.scale,1);
 if(Math.abs(next-state.dynamicScale)>.035){state.dynamicScale=next;telemetry.lastScaleChangeAt=t;resize();}
}
let lastSampleDisplay=0;
function tick(t){
  if(!running)return;
  try{
    telemetry.uiFrames++;
    if(!telemetry.periodStart)telemetry.periodStart=t;
    if(!waterLastTime)waterLastTime=t;
    const dt=Math.min(.05,Math.max(0,(t-waterLastTime)/1000));waterLastTime=t;
    if(state.waterVisible&&!fluid.paused && (fluid.playing||fluid.drops.length||t<waterMovingUntil)){
      fluid.step(dt);
      // Same numerical fluid solver and same time-stepping limits in all modes.
      telemetry.physicsSeconds+=Math.min(.04,dt);telemetry.hadPhysics=true;
      uploadFluid();invalidate();
      if(t-lastPhysicsFrame>120){updateWaterStats();lastPhysicsFrame=t;}
    }
    pollGpuSample(t);
    const m=qualityModes[state.quality];
    const due=t-telemetry.lastTraceAt>=m.frameIntervalMs;
    if(due&&!state.captureReady&&state.samples<(state.captureActive?state.captureTargetSamples:m.maxSamples)){
      if(!guideReady)renderGuide();
      const timed=beginGpuSample(t);
      renderTrace();
      if(timed)gl.endQuery(telemetry.gpuExtension.TIME_ELAPSED_EXT);
      telemetry.lastTraceAt=t;state.redraw=true;
    }
    if(state.redraw&&state.samples>0){renderDisplay();state.redraw=false;}
    if(state.captureActive){
      const captured=state.samples-state.captureStartSample;
      if(!state.captureReady && captured>=state.captureTargetSamples){
        state.captureReady=true;
        renderDisplay();
        toast('Reference capture ready · click SAVE PNG, then RETURN TO LIVE');
      }
      if(t-lastSampleDisplay>225 || state.captureReady)updateCaptureUI();
    }
    if(t-lastSampleDisplay>450){
      $('samples').textContent=state.samples+' SPP';
      $('renderer-state').textContent=state.captureActive?('CAPTURE '+(state.samples-state.captureStartSample)+' / '+state.captureTargetSamples+' SPP'):(state.samples<12?'CONVERGING':m.label+' TRACING');lastSampleDisplay=t;
    }
    if(t-telemetry.periodStart>=1200){
      const seconds=(t-telemetry.periodStart)/1000;
      $('display-fps').textContent=(telemetry.displayFrames/seconds).toFixed(1);
      $('trace-fps').textContent=(telemetry.traceFrames/seconds).toFixed(1);
      $('physics-speed').textContent=!state.waterVisible?'OFF':fluid.paused?'PAUSED':(!telemetry.hadPhysics?'IDLE':(telemetry.physicsSeconds/seconds).toFixed(2)+'×');
      telemetry.displayFrames=0;telemetry.traceFrames=0;telemetry.physicsSeconds=0;telemetry.hadPhysics=false;telemetry.periodStart=t;
    }
    requestAnimationFrame(tick);
  }catch(err){running=false;console.error(err);$('renderer-state').textContent='RENDER ERROR';toast(err.message);}
}
function viewRayAt(x,y){
  const basis=cameraBasis();
  const ndcX=((x/window.innerWidth)*2-1)*(window.innerWidth/window.innerHeight)+.16;
  const ndcY=(1-(y/window.innerHeight)*2);
  const tan=Math.tan(48*Math.PI/360);
  return{origin:basis.position,dir:normalize(add(add(basis.forward,mul(basis.right,ndcX*tan)),mul(basis.up,ndcY*tan)))};
}
function project(world){
  const b=cameraBasis();const v=sub(world,b.position);const z=dot(v,b.forward);if(z<=0)return[-999,-999];
  const tangent=Math.tan(48*Math.PI/360);
  const nx=(dot(v,b.right)/z/tangent-.16)/(window.innerWidth/window.innerHeight);
  const ny=(dot(v,b.up)/z/tangent);
  return[(nx+1)*window.innerWidth*.5,(1-ny)*window.innerHeight*.5];
}
function dragOrb(x,y,vertical,change){
  if(vertical){state.orbPos[1]=clamp(state.orbPos[1]-(y-state.prevY)*.008,.85,2.6);}
  else{
    const r=viewRayAt(x,y);let t=(state.orbPos[1]-r.origin[1])/r.dir[1];
    if(t>0&&t<60){const w=add(r.origin,mul(r.dir,t));state.orbPos[0]=clamp(w[0],-1.85,1.85);state.orbPos[2]=clamp(w[2],-1.65,1.9);}
  }
  if(change){updateOrbFields();invalidate();}
}
function updateOrbFields(){for(const [index,id] of ['orb-x','orb-y','orb-z'].entries())$(id).value=state.orbPos[index].toFixed(2);}
function setWaterPose(x,z,rx,rz,dt){
 if(!state.waterVisible)return;
 fluid.setPose(x,z,rx,rz,dt);
 uploadFluid();invalidate();updateWaterStats();waterMovingUntil=performance.now()+5000;
}
function waterFields(){
 $('cup-x').value=fluid.cupPos[0].toFixed(2);$('cup-z').value=fluid.cupPos[2].toFixed(2);
 $('cup-tilt-x').value=Math.round(fluid.angles[0]*180/Math.PI);
 $('cup-tilt-z').value=Math.round(fluid.angles[1]*180/Math.PI);
 $('tilt-x-label').textContent=$('cup-tilt-x').value+'°';$('tilt-z-label').textContent=$('cup-tilt-z').value+'°';
}
function focusWater(){state.yaw=.57;state.pitch=.32;state.radius=.46;state.target=[-.08,.84,.258];state.waterFocus=true;invalidate();}
function focusRoom(){state.yaw=.60;state.pitch=.29;state.radius=3.68;state.target=[0,.80,-.04];state.waterFocus=false;invalidate();}
function updateWaterUI(){
  $('water-visible').checked=state.waterVisible;
  $('water-quick-toggle').textContent=state.waterVisible?'CUP + WATER: ON':'CUP + WATER: OFF';
  $('water-quick-toggle').setAttribute('aria-pressed',String(state.waterVisible));
  $('water-mode-label').textContent=state.waterVisible?'VISIBLE · simulation active':'HIDDEN · physics suspended';
  document.querySelectorAll('[data-requires-water]').forEach(el=>{el.disabled=!state.waterVisible;});
  $('water-status').textContent=!state.waterVisible?'HIDDEN':(state.captureActive?'CAPTURE PAUSE':(fluid.paused?'PAUSED':'SIMULATING'));
}
function setWaterVisible(visible){
  const next=Boolean(visible);
  if(next===state.waterVisible)return;
  state.waterVisible=next;
  // Hide all procedural surfaces and suspend simulation, but retain the
  // numerical ledger so toggling back restores precisely the same state.
  if(!next){waterMovingUntil=0;focusRoom();}
  invalidate();updateWaterUI();
  toast(next?'Cup and water enabled':'Cup, droplets, and desk water removed from render');
}
function bindControls(){
  $('water-visible').addEventListener('change',e=>setWaterVisible(e.target.checked));
  $('water-quick-toggle').addEventListener('click',()=>setWaterVisible(!state.waterVisible));
  $('reset-water').addEventListener('click',()=>{fluid.reset();waterMovingUntil=0;uploadFluid();updateWaterStats();waterFields();$('water-pause').checked=false;invalidate();toast('Cup reset · spilled volume restored');});
  $('water-pause').addEventListener('change',e=>{fluid.paused=e.target.checked;updateWaterStats();invalidate();});
  $('focus-water').addEventListener('click',()=>{if(state.waterVisible)focusWater();});
  $('water-optics').addEventListener('click',()=>{
    if(!state.waterVisible)return;
    state.orbPos=[-.30,1.16,.42];state.orb=true;state.power=105;
    $('orb-toggle').checked=true;$('intensity').value='105';$('intensity-label').textContent='105%';
    updateOrbFields();focusWater();invalidate();toast('Movable physical emitter positioned beside cup');
  });
  $('focus-room').addEventListener('click',focusRoom);
  for(const [field,index] of [['cup-x',0],['cup-z',2]])$(field).addEventListener('change',()=>{
    const x=index===0?+$(field).value:fluid.cupPos[0],z=index===2?+$(field).value:fluid.cupPos[2];
    setWaterPose(x,z,fluid.angles[0],fluid.angles[1],.05);waterFields();
  });
  for(const [field,index] of [['cup-tilt-x',0],['cup-tilt-z',1]])$(field).addEventListener('input',()=>{
    const ang=Number($(field).value)*Math.PI/180;
    setWaterPose(fluid.cupPos[0],fluid.cupPos[2],index===0?ang:fluid.angles[0],index===1?ang:fluid.angles[1],.05);waterFields();
  });
  $('room-toggle').addEventListener('change',e=>{state.room=e.target.checked;invalidate();});
  $('lamp-toggle').addEventListener('change',e=>{state.lamp=e.target.checked;invalidate();});
  $('orb-toggle').addEventListener('change',e=>{state.orb=e.target.checked;invalidate();});
  $('intensity').addEventListener('input',e=>{state.power=+e.target.value;$('intensity-label').textContent=state.power+'%';state.orb=true;$('orb-toggle').checked=true;invalidate();});
  $('exposure').addEventListener('input',e=>{state.exposure=+e.target.value/100;$('exposure-label').textContent=state.exposure.toFixed(2)+'×';state.redraw=true;});
  $('filter-toggle').addEventListener('change',e=>{state.noiseFilter=e.target.checked;state.redraw=true;});
  ['orb-x','orb-y','orb-z'].forEach((id,index)=>$(id).addEventListener('input',e=>{const n=parseFloat(e.target.value);if(Number.isFinite(n)){const bounds=[[-1.85,1.85],[.85,2.6],[-1.65,1.9]][index];state.orbPos[index]=clamp(n,...bounds);state.orb=true;$('orb-toggle').checked=true;invalidate();}}));
  $('reset-sphere').onclick=()=>{state.orbPos=[0,1.85,.7];updateOrbFields();invalidate();};
  document.querySelectorAll('[data-quality]').forEach(btn=>btn.addEventListener('click',()=>setMode(btn.dataset.quality)));
  $('quick-mode').addEventListener('click',()=>setMode(LightLabQuality.nextQuickMode(state.quality,state.lastNonPerformanceMode)));
  $('auto-balance').addEventListener('change',e=>{state.autoBalance=e.target.checked;
    if(!state.autoBalance){state.dynamicScale=1;resize();}
  });
  $('motion-preview').addEventListener('change',e=>{state.motionPreview=e.target.checked;
    if(!state.motionPreview)setMovingPreview(false);
  });
  document.querySelectorAll('[data-preset]').forEach(btn=>btn.addEventListener('click',()=>{
    const preset=btn.dataset.preset;
    state.room=preset==='studio';state.lamp=preset!=='orb';state.orb=preset==='orb';
    $('room-toggle').checked=state.room;$('lamp-toggle').checked=state.lamp;$('orb-toggle').checked=state.orb;
    invalidate();toast(preset==='studio'?'Overhead and desk lamp active':preset==='night'?"Only the banker's lamp illuminates the room":'Movable sphere is the only light');
  }));
  $('reset-camera').onclick=()=>{if(state.waterVisible)focusWater();else focusRoom();};
  $('capture').onclick=()=>{startCapture();};
  $('capture-save').onclick=()=>{saveCanvasPNG();};
  canvas.addEventListener('pointerdown',e=>{if(state.captureActive)return;
    canvas.setPointerCapture(e.pointerId);
    const sx=e.clientX,sy=e.clientY;const projected=project(state.orbPos);
    const cp=project([fluid.cupPos[0],fluid.cupPos[1]+.055,fluid.cupPos[2]]);
    state.dragMode=(state.orb&&Math.hypot(sx-projected[0],sy-projected[1])<35)?'orb':
      (state.waterVisible&&Math.hypot(sx-cp[0],sy-cp[1])<Math.max(30,85/state.radius)?'cup':'orbit');
    state.dragging=true;state.prevX=sx;state.prevY=sy;canvas.classList.add('dragging');
    setMovingPreview(true);
  });
  canvas.addEventListener('pointermove',e=>{if(state.captureActive)return;
    if(!state.dragging){if(state.orb){const p=project(state.orbPos);canvas.classList.toggle('light-hover',Math.hypot(e.clientX-p[0],e.clientY-p[1])<45);}return;}
    const dx=e.clientX-state.prevX,dy=e.clientY-state.prevY;
    if(state.dragMode==='orb')dragOrb(e.clientX,e.clientY,e.shiftKey,true);
    else if(state.dragMode==='cup'){
      if(e.shiftKey){setWaterPose(fluid.cupPos[0],fluid.cupPos[2],
        clamp(fluid.angles[0]+dy*.012,-.90,.90),clamp(fluid.angles[1]+dx*.012,-.90,.90),.04);}
      else{
        const r=viewRayAt(e.clientX,e.clientY), t=(fluid.cupPos[1]-r.origin[1])/r.dir[1];
        if(t>0&&t<60){const w=add(r.origin,mul(r.dir,t));setWaterPose(w[0],w[2],fluid.angles[0],fluid.angles[1],.04);}
      }
      waterFields();
    }
    else{state.yaw-=dx*.006;state.pitch=clamp(state.pitch+dy*.004,-.08,1.12);invalidate();}
    state.prevX=e.clientX;state.prevY=e.clientY;
  });
  const endDrag=()=>{if(state.captureActive)return;if(state.dragMode==='cup')waterMovingUntil=performance.now()+6500;
    state.dragging=false;state.dragMode=null;canvas.classList.remove('dragging');setMovingPreview(false);};
  canvas.addEventListener('pointerup',endDrag);canvas.addEventListener('pointercancel',endDrag);
  canvas.addEventListener('wheel',e=>{if(state.captureActive)return;e.preventDefault();state.radius=clamp(state.radius*Math.exp(e.deltaY*.0012),1.7,6.8);invalidate();},{passive:false});
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  window.addEventListener('resize',()=>{if(gl&&running){if(state.captureActive)cancelCapture();resize();}});
  document.addEventListener('keydown',e=>{
    if(state.captureActive){if(e.key==='Escape')cancelCapture();return;}
    if(e.target instanceof HTMLInputElement)return;
    const k=e.key.toLowerCase();
    if(k==='l'){$('room-toggle').click();}if(k==='b'){$('lamp-toggle').click();}if(k==='o'){$('orb-toggle').click();}
    if(k==='r')$('reset-camera').click();
    if(['1','2','3'].includes(k))setMode(({ '1':'reference','2':'balanced','3':'performance' })[k]);
    if(k==='f')$('quick-mode').click();
    if(k==='w')$('water-quick-toggle').click();
  });
}
async function initialize(){
  try{
    setupRenderer();showLoad('Reading imported 3D geometry…');
    const [json,tris,bvh]=await Promise.all([
      fetch('assets/scene.json').then(r=>{if(!r.ok)throw Error('Could not load scene.json');return r.json();}),
      fetch('assets/triangles.bin').then(r=>{if(!r.ok)throw Error('Could not load triangle mesh');return r.arrayBuffer();}),
      fetch('assets/bvh.bin').then(r=>{if(!r.ok)throw Error('Could not load BVH');return r.arrayBuffer();})
    ]);
    meta=json;triTexture=makeDataTexture(tris,meta.triangleTexels,meta.triangleCount);bvhTexture=makeDataTexture(bvh,meta.nodeTexels,meta.nodeCount);
    showLoad('Calibrating physically based materials…');
    [deskColor,deskRough,deskNormal,brassColor,brassRough]=await Promise.all([loadImageTexture('assets/desk-color.webp',true),loadImageTexture('assets/desk-roughness.webp',false),loadImageTexture('assets/desk-normal.webp',false),loadImageTexture('assets/brass-color.webp',true),loadImageTexture('assets/brass-roughness.webp',false)]);
    $('tri-count').textContent=meta.triangleCount.toLocaleString('en-US');
    bindControls();focusRoom();waterFields();updateWaterStats();updateWaterUI();updateModeUI();updateCaptureUI();resize();running=true;
    $('render-led').style.background='#d6ac75';$('renderer-state').textContent='PATH TRACER ACTIVE';
    $('load-screen').classList.add('done');setTimeout(()=>$('load-screen').remove(),700);
    requestAnimationFrame(tick);
  }catch(e){console.error('LightLab initialization failed:',e);showLoad('Cannot initialize: '+e.message);$('renderer-state').textContent='WEBGL UNAVAILABLE';$('render-led').style.background='#ba4b49';$('load-screen').querySelector('.loading-line').style.display='none';}
}
initialize();
