@echo off
cd /d "%~dp0"
echo Starting LightLab local web application...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-LightLab.ps1"
if errorlevel 1 (
  echo PowerShell could not start the local server.
  echo Alternative: run python serve.py from this folder.
  pause
)
