# LightLab v1.5.1 — GLSL Shader Initialization Hotfix

This is a cumulative replacement for v1.5. It corrects the GLSL ES 3.00 reserved keyword `sample` used as a local variable inside the path-tracing fragment shader. Only the local name and its references changed; the light-transport equations and controls are preserved.

Extract the entire ZIP and run **Launch LightLab.bat**. Do not copy a single file into an older archive or overwrite just the page while leaving the browser cache unchanged. If you already have the old page open, close and reopen it or do a hard reload (Ctrl+Shift+R).

The optional GPU safety-monitor upgrade is **not included** in this compatibility hotfix.

## GLSL verification
`node developer/extract_shaders.cjs` (from source kit), then `python developer/validate_shaders.py` where Mesa and VTK are available. The shader identifier regression test checks the embedded GLSL source directly.

---

# LightLab v1.4 — Lighting Isolation & Water Artifact Corrections

A **complete cumulative Windows 11 / Brave / Chrome WebGL2 web app**. Retains the three user-provided FBX-derived assets (desk, banker lamp, 15-inch-class ViewSonic CRT), room/lamp/orb controls, reference/balanced/performance renderer, and procedural 75%-filled tumbler.

## Run

1. Extract the entire ZIP, keeping `assets/` next to `main.js`.
2. Open `LightLab_WebApp` and double-click **Launch LightLab.bat**. It starts a local PowerShell-based HTTP server and opens your browser.
3. **The cup and every water surface are OFF by default.** Use the top-bar **CUP + WATER: OFF / ON** button or the switch under section 04. Keyboard **W** also switches the water system.
4. When ON, the existing cup movement, tilting, optical-light preset and **RESET CUP + ALL WATER** operate as before. Toggling water OFF hides the cup, its liquid, airborne droplets and tabletop film from every ray intersection and suspends water physics. ON restores the stored water state. Reset restores all water volume to the cup and clears spills.
5. Choose **Reference** (1), **Balanced** (2; default), **Performance** (3), or **Quick Performance** (F). Use the **ROOM VIEW** button to frame the entire lighting test.

Browser needs working WebGL2 and `EXT_color_buffer_float`; hardware acceleration enabled. Automatic GPU resolution adjustment additionally requires `EXT_disjoint_timer_query_webgl2`.

## v1.4 corrections

- **Independent light-only testing:** New water on/off switch, OFF by default; all cup/water intersections and associated physics are gated. Off mode returns to room view instead of leaving the camera staring at an empty cup close-up.
- **Transmissive shadow rays:** In v1.3, a direct-light shadow connection hitting glass or water was treated as fully opaque. v1.4 evaluates **unpolarized dielectric Fresnel transmission and Beer–Lambert attenuation** across surfaces for a straight-line thin/locally-parallel-layer approximation. This reduces false black cutouts. **This is not a fully accurate refractive connection through curved glass or a true caustics solver; the approximation is explicitly limited.** Primary path-traced dielectric rays still use Snell's law and exact Fresnel equations for ideal interfaces.
- **Artificial visual grain removed:** A CSS noise overlay was previously drawn across the canvas; this is deleted. Remaining speckles are ray-tracing sampling noise rather than added decoration.
- **Display denoiser corrected:** The old log-space bilateral filter can make reflections look unnaturally dark/blotchy. Replaced with a small, geometry-guided linear-radiance display-only filter; **OFF by default** to preserve the raw physical light estimate. Reenable it deliberately for faster previews. It never modifies the path-traced accumulation.
- **Direct-light variance:** All actual lights are now explicitly sampled at the first **two** non-specular surface bounces instead of only the first. This raises computation cost but reduces visible variance in important indirect illumination.
- **Puddle footprints:** Impact volume is deposited conservatively into the four adjacent film cells at the measured collision position, **not artificially expanded into a preset 5×5 Gaussian circular puddle**. The film transport solver, not an image decal, then evolves the film.
- **Rest-state accumulation:** When the discrete cup fluid is demonstrably quiescent within the solver's spatial resolution and there are no airborne droplets or desk water, the solver sleeps rather than invalidating the light result indefinitely. The solver continues running for ongoing spills/desk-film evolution, where changing geometry truly prevents accumulating samples across times.
- **Balanced defaults:** Initial render resolution modestly increased from 65% to 72% of native width/height before any optional auto-adjustment. Performance still targets lower pixel count for responsiveness.

## Honest limitations

LightLab remains an experimental renderer. **Do not equate v1.4 with validated or exact glass/water light transport.** Straight-line thin-layer shadow transmittance is a deliberate approximation; refraction can redirect rays, produce real caustics or genuine dark regions. Recovering those accurately needs a refractive light-path connection or photon/BDPT-style solver. RGB absorption and refractive indices are approximate. Current fluids are a 40×40 depth-averaged cup model, 144×72 viscous tabletop film, and ballistic parcels: not a full 3D free-surface CFD solver. Wetting/contact angles, actual fine droplets, detailed splash breakup, and thin film contact-line behavior remain unresolved. Finite path depth and noisy low-SPP previews also remain.

### How to compare

With water OFF, hold the camera still in Reference mode and observe SPP increasing. With water ON, move the cup and spill a very small amount, then use **Pause fluid / refine image** when you need a cleaner comparison. Toggle water OFF to isolate lighting and inspect material/shadow artifacts without the fluid geometry. No artificial ambient light or rainbow overlay has been added. A high-quality still estimate can take considerably longer than a 60 FPS preview on a GTX 1080.

## Verification performed

- Node.js syntax validation for `main.js`, `fluid.js`, and `quality.js`.
- Geometry/off-by-default and volume-conservation regressions.
- Headless browser DOM test: cup OFF by default, ON/ OFF state retention, water controls disabled when hidden, mass ledger retained, reset clears all reservoirs.
- GLSL shaders compiled and linked under Mesa OpenGL 4.5 after translation from GLSL ES; offscreen renderer generated finite images with water ON and OFF.
- **Not verified:** Actual interactive WebGL2 and GTX 1080 frame rate on the user's Windows/Brave environment. Offscreen rendering uses a desktop OpenGL test path, not the identical browser GPU driver path.

## Controls

W: cup & water | L: room lights | B: banker's lamp | O: sphere | 1/2/3: quality modes | F: Quick Performance | R: reset camera | Drag: orbit (or cup/sphere when enabled) | Mouse wheel: zoom.


## v1.5 — Frozen Reference Render Capture

Use **RENDER CAPTURE** (lower-right), selecting **512 / 2,048 / 8,192 / 16,384 samples per pixel** beforehand. The app freezes the cup and water, camera and all scene controls, sets unfiltered 12-bounce Reference mode, and progressively averages independent paths. Press **SAVE PNG** at any point to download the currently accumulated, tonemapped image. When the target is reached, the image **remains visible and frozen** until you press **RETURN TO LIVE**. Escape cancels capture; resizing the browser exits it. The sample target is *not* a proof that the image has mathematically converged; high quality takes more time.

Physics correction: Fresnel reflection vs transmission for the thin desk film is now chosen stochastically without double-counting the nonreflection probability. This avoids artificially darkening transmission. Complex refractive caustics are not yet simulated exactly. Reference and Balanced use **unclamped** light samples; optional Performance-only preview sample limiting introduces bias. The optional spatial preview denoiser runs on the *display only* and never changes the accumulated raw light estimates. Capture always disables denoising and sample clipping. 

**Corrected puddle-substrate ray geometry:** when a camera ray transmits through the thin water film it now shades the actual wood mesh underneath instead of advancing past that mesh by a generic ray epsilon. This removes an important numerical cause of false black puddles. The film remains a simplified thin-film interface; it does not yet generate full caustics or resolve wavelength-dependent dispersion.
