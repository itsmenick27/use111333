/* LightLab mode configuration — display and sampling budgets only.
   The conserved physical fluid state is never reinitialized by quality changes.
   Reference and Balanced retain the same 12-bounce optical transport model;
   Performance truncates paths at eight bounces (declared finite-depth bias).
   All modes keep the same 40x40 fluid grid and all mass reservoirs.
*/
'use strict';
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.LightLabQuality = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const MODES = Object.freeze({
    reference: Object.freeze({
      label: 'REFERENCE', scale: 1, minScale: 1, bounces: 12,
      targetGpuMs: 0, frameIntervalMs: 0, maxSamples: 16384, firstPassSpp: 3,
      movingScale: 1, autoAdjust: false,
      description: '12 bounces · native render resolution · unrestricted progressive sampling',
      limitation: 'Slow by design. Finite 12-bounce RGB path tracing is not an unbiased or spectral reference.'
    }),
    balanced: Object.freeze({
      label: 'BALANCED', scale: .72, minScale: .41, bounces: 12,
      targetGpuMs: 18, frameIntervalMs: 13, maxSamples: 8192, firstPassSpp: 4,
      movingScale: .76, autoAdjust: true,
      description: '12 bounces · 72% native starting resolution · adaptive GPU scale',
      limitation: 'Reduced image resolution and sparse ray sampling cause visible noise during motion.'
    }),
    performance: Object.freeze({
      label: 'PERFORMANCE', scale: .47, minScale: .28, bounces: 8,
      targetGpuMs: 14, frameIntervalMs: 8, maxSamples: 4096, firstPassSpp: 2,
      movingScale: .80, autoAdjust: true,
      description: '8 bounces · adaptive image resolution · conserved fluid',
      limitation: 'Finite 8-bounce path truncation introduces more light-transport bias.'
    })
  });
  function dimensions(width, height, dpr, mode, dynamicScale = 1, moving = false) {
    const m = MODES[mode];
    if (!m) throw Error('Unknown LightLab mode: ' + mode);
    const w = Math.max(320, width), h = Math.max(240, height);
    const density = Math.min(1.8, Math.max(1, dpr || 1));
    const base = m.scale * Math.max(0.25, Math.min(1, dynamicScale));
    const preview = moving ? m.movingScale : 1;
    const scale = Math.max(m.minScale * .65, Math.min(m.scale, base * preview));
    // Scale both axes together to preserve photographic projection aspect ratio.
    const nativeWidth = w * density * scale, nativeHeight = h * density * scale;
    const cap = Math.min(1, 1920 / nativeWidth, 1080 / nativeHeight);
    return {
      canvasW: Math.round(w * density), canvasH: Math.round(h * density),
      width: Math.max(1, Math.round(nativeWidth * cap)),
      height: Math.max(1, Math.round(nativeHeight * cap)),
      scale
    };
  }
  function nextQuickMode(current, returnMode) {
    if (current === 'performance') return returnMode && returnMode !== 'performance' ? returnMode : 'balanced';
    return 'performance';
  }
  return Object.freeze({ MODES, dimensions, nextQuickMode });
});
