from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import os,webbrowser
os.chdir(Path(__file__).resolve().parent)
port=8765
print(f'LightLab running at http://localhost:{port} — press Ctrl+C to stop')
ThreadingHTTPServer(('127.0.0.1',port),SimpleHTTPRequestHandler).serve_forever()
