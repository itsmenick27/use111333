# LightLab local web server. Runs on Windows PowerShell 5.1+ without Python/Node.
$ErrorActionPreference = 'Stop'
$base = [System.IO.Path]::GetFullPath($PSScriptRoot)
$tcp = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
$tcp.Start()
$port = ([System.Net.IPEndPoint]$tcp.LocalEndpoint).Port
$url = "http://127.0.0.1:$port/"
Write-Host "LightLab is running at $url" -ForegroundColor Cyan
Write-Host 'This server is local to your computer. Press Ctrl+C to stop.'
Start-Process $url
$mimeMap = @{
    '.html' = 'text/html; charset=utf-8'
    '.css' = 'text/css; charset=utf-8'
    '.js' = 'application/javascript; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'
    '.bin' = 'application/octet-stream'
    '.webp' = 'image/webp'
    '.png' = 'image/png'
    '.ico' = 'image/x-icon'
}
try {
    while ($true) {
        $client = $tcp.AcceptTcpClient()
        $client.NoDelay = $true
        $stream = $client.GetStream()
        try {
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)
            $line = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            # Read all request headers; the demo only accepts GET and HEAD.
            while ($true) {
                $header = $reader.ReadLine()
                if ($null -eq $header -or $header -eq '') { break }
            }
            $parts = $line.Split(' ')
            $method = $parts[0]
            $request = if ($parts.Length -ge 2) { $parts[1] } else { '/' }
            $request = $request.Split('?')[0]
            try { $request = [System.Uri]::UnescapeDataString($request) } catch { $request = '/' }
            $relative = $request.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
            if ($relative -eq '') { $relative = 'index.html' }
            $full = [System.IO.Path]::GetFullPath((Join-Path $base $relative))
            $allowed = $full.StartsWith($base + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
            $exists = $allowed -and (Test-Path -LiteralPath $full -PathType Leaf)
            $status = if ($exists -and ($method -eq 'GET' -or $method -eq 'HEAD')) { '200 OK' } else { '404 Not Found' }
            if ($status -eq '200 OK') {
                $bytes = [System.IO.File]::ReadAllBytes($full)
                $extension = [System.IO.Path]::GetExtension($full).ToLowerInvariant()
                $mime = if ($mimeMap.ContainsKey($extension)) { $mimeMap[$extension] } else { 'application/octet-stream' }
            } else {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes('Not found')
                $mime = 'text/plain; charset=utf-8'
            }
            $responseHeaders = "HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-cache`r`nX-Content-Type-Options: nosniff`r`n`r`n"
            $head = [System.Text.Encoding]::ASCII.GetBytes($responseHeaders)
            $stream.Write($head, 0, $head.Length)
            if ($method -ne 'HEAD') { $stream.Write($bytes, 0, $bytes.Length) }
        } catch {
            Write-Warning $_.Exception.Message
        } finally {
            try { $stream.Close() } catch {}
            $client.Close()
        }
    }
} finally {
    $tcp.Stop()
}
