from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import webbrowser,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
srv=ThreadingHTTPServer(('127.0.0.1',0),SimpleHTTPRequestHandler)
print('LightLab Gaming: http://127.0.0.1:%d/'%srv.server_port)
webbrowser.open('http://127.0.0.1:%d/'%srv.server_port)
srv.serve_forever()
