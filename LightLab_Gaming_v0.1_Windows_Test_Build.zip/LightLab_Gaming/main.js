/* LightLab Gaming v0.1. Independent from Scientific v1.5.1.
   Optimized custom WebGL2 raster PBR, GGX, punctual emitters, shadow maps,
   approximate screen-space dielectric transmission, SI-units fluid module.
   Opaque shading only accounts for directly visible explicit light sources;
   unmodeled indirect irradiance is NOT invented. All limitations documented.
*/
'use strict';
const el=id=>document.getElementById(id),canvas=el('view'),SH=LightLabGameShaders;
const S={room:true,lamp:true,orb:false,orbPower:55,orbPos:[0,1.85,.7],exposure:1,
  water:false,mode:'balanced',scale:1,adaptive:false,shadowSamples:4,
  yaw:.60,pitch:.29,dist:3.6,target:[0,.8,-.04],cupFocused:false,
  isDragging:false,prevX:0,prevY:0,frames:0,lastNow:0,fps:0,frameTime:0,
  waterLast:0,movementCount:0,sceneChanged:true};
const fluid=new LightLabFluid.FluidStudy();
const WMat=window.Math;
const clamp=(x,lo,hi)=>Math.min(hi,Math.max(lo,x));
const plus=(a,b)=>a.map((v,i)=>v+b[i]);const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const mult=(v,f)=>v.map(x=>x*f);const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2]];
const unit=v=>mult(v,1/(Math.hypot(...v)||1));
function identity(){return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]);}
function perspective(deg,aspect,near,far){const f=1/Math.tan(deg*Math.PI/360),n=1/(near-far);
  return new Float32Array([f/aspect,0,0,0, 0,f,0,0, 0,0,(far+near)*n,-1, 0,0,2*far*near*n,0]);}
function lookAt(eye,target,up=[0,1,0]){const z=unit(sub(eye,target)),x=unit(cross(up,z)),y=cross(z,x);
 return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,
 -(x[0]*eye[0]+x[1]*eye[1]+x[2]*eye[2]),-(y[0]*eye[0]+y[1]*eye[1]+y[2]*eye[2]),-(z[0]*eye[0]+z[1]*eye[1]+z[2]*eye[2]),1]);}
function mm(a,b){const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)out[c*4+r]+=a[k*4+r]*b[c*4+k];return out;}
function TRS(pos=[0,0,0],rx=0,rz=0){const [cx,sx,cz,sz]=[Math.cos(rx),Math.sin(rx),Math.cos(rz),Math.sin(rz)];
 return new Float32Array([cz,sz,0,0,-sz*cx,cz*cx,sx,0,sz*sx,-cz*sx,cx,0,pos[0],pos[1],pos[2],1]);}
const gl=canvas.getContext('webgl2',{antialias:true,alpha:false,stencil:false,depth:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
if(!gl){el('error').hidden=false;el('error').textContent='WebGL2 unavailable. Enable hardware acceleration in Brave / Chrome.';throw Error('WebGL2 unavailable');}
const floatRender=!!gl.getExtension('EXT_color_buffer_float');
if(!floatRender){el('error').hidden=false;el('error').textContent='EXT_color_buffer_float is required for physical radiance buffers. Check Brave GPU acceleration.';throw Error('Float color buffer unavailable');}
let info, mesh, ranges=[],opaqueBatches=[],glassBatches=[],programs={},uniforms={},textures={},depthMaps=[],depthFB=[],opaqueFB,compositeFB,opaqueTex,compositeTex,sceneDepth,depthRbo,internalW=0,internalH=0,quadVAO,shadowDirty=true;
let waterMesh=null,cupMesh=null,filmMesh=null,sphereMesh=null,shadowMatrices=[identity(),identity(),identity()],lastWaterDraw=0,fluidSeconds=0,fpsWindow=0,fpsFrames=0,frameHistory=[],benchmarking=false,benchStart=0,benchFrames=[];
let raf=0;
function fail(e){const t=e instanceof Error?e.stack||e.message:String(e);console.error(t);el('error').hidden=false;el('error').textContent='LIGHTLAB GAMING INITIALIZATION ERROR\n'+t;el('status').textContent='ERROR';}
function compile(t,src){const sh=gl.createShader(t);gl.shaderSource(sh,src);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS)){let msg=gl.getShaderInfoLog(sh);gl.deleteShader(sh);throw Error('Shader compile: '+msg);}return sh;}
function prog(v,f){const vs=compile(gl.VERTEX_SHADER,v),fs=compile(gl.FRAGMENT_SHADER,f),p=gl.createProgram();gl.attachShader(p,vs);gl.attachShader(p,fs);gl.linkProgram(p);
 if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('Shader link: '+gl.getProgramInfoLog(p));gl.deleteShader(vs);gl.deleteShader(fs);return p;}
function uniformsFor(p){const o={};const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);for(let i=0;i<n;i++){const a=gl.getActiveUniform(p,i);if(a){const key=a.name.replace(/\[0\]$/,'');o[key]=gl.getUniformLocation(p,a.name);}}return o;}
function bufferMesh(data,usage=gl.STATIC_DRAW){const vao=gl.createVertexArray(),buf=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,data,usage);
 gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,32,0);
 gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,32,12);
 gl.enableVertexAttribArray(2);gl.vertexAttribPointer(2,2,gl.FLOAT,false,32,24);gl.bindVertexArray(null);
 return{vao,buf,count:data.length/8,usage};}
function updateMesh(mesh,data){gl.bindBuffer(gl.ARRAY_BUFFER,mesh.buf);gl.bufferData(gl.ARRAY_BUFFER,data,gl.DYNAMIC_DRAW);mesh.count=data.length/8;}
const vertex=(arr,pos,nor,uv=[0,0])=>{arr.push(...pos,...nor,...uv);};
function generateCup(){const a=[],n=56,r=.04,ri=.037,h=.112,b=.004;
 const rings=[[r,0],[r,h],[ri,h],[ri,b],[0,b]];
 const quad=(p0,p1,p2,p3,normal)=>{vertex(a,p0,normal);vertex(a,p1,normal);vertex(a,p2,normal);vertex(a,p0,normal);vertex(a,p2,normal);vertex(a,p3,normal);};
 for(let i=0;i<n;i++){const t=i*2*Math.PI/n,t1=(i+1)*2*Math.PI/n;
  for(let k=0;k<4;k++){const [R0,Y0]=rings[k],[R1,Y1]=rings[k+1];
   if(k===3){const p=[Math.cos(t)*ri,b,Math.sin(t)*ri],q=[Math.cos(t1)*ri,b,Math.sin(t1)*ri];
    vertex(a,[0,b,0],[0,1,0]);vertex(a,p,[0,1,0]);vertex(a,q,[0,1,0]);continue;}
   const p0=[Math.cos(t)*R0,Y0,Math.sin(t)*R0],p1=[Math.cos(t1)*R0,Y0,Math.sin(t1)*R0];
   const p2=[Math.cos(t1)*R1,Y1,Math.sin(t1)*R1],p3=[Math.cos(t)*R1,Y1,Math.sin(t)*R1];
   const norm=k===0?[Math.cos((t+t1)/2),0,Math.sin((t+t1)/2)]:k===2?[-Math.cos((t+t1)/2),0,-Math.sin((t+t1)/2)]:[0,1,0];quad(p0,p1,p2,p3,norm);}
 }return new Float32Array(a);}
function generateWater(){const a=[],N=fluid.N,dx=fluid.dx,r=fluid.P.innerRadius,h=fluid.h;
 const hh=(x,z)=>h[clamp(z,0,N-1)*N+clamp(x,0,N-1)];
 function add(x,z){const i=z*N+x;const xx=-r+(x+.5)*dx,zz=-r+(z+.5)*dx;
 const gx=(hh(x+1,z)-hh(x-1,z))/(2*dx),gz=(hh(x,z+1)-hh(x,z-1))/(2*dx);
 vertex(a,[xx,.004+h[i],zz],unit([-gx,1,-gz]),[(xx+r)/(2*r),(zz+r)/(2*r)]);}
 for(let z=0;z<N-1;z++)for(let x=0;x<N-1;x++){
  const i=z*N+x;if(!(fluid.frac[i]&&fluid.frac[i+1]&&fluid.frac[i+N]&&fluid.frac[i+N+1]))continue;
  add(x,z);add(x,z+1);add(x+1,z+1);add(x,z);add(x+1,z+1);add(x+1,z);
 }return new Float32Array(a);}
function createFilmGrid(){const a=[],nx=72,nz=36,P=fluid.P;
 const add=(x,z)=>{const xx=P.filmXmin+(P.filmXmax-P.filmXmin)*x/nx,zz=P.filmZmin+(P.filmZmax-P.filmZmin)*z/nz;
  vertex(a,[xx,P.deskY+.001,zz],[0,1,0],[x/nx,z/nz]);};
 for(let z=0;z<nz;z++)for(let x=0;x<nx;x++){add(x,z);add(x,z+1);add(x+1,z+1);add(x,z);add(x+1,z+1);add(x+1,z);}
 return new Float32Array(a);}
function makeSphere(){const a=[],s=18,t=12;for(let y=0;y<t;y++)for(let x=0;x<s;x++){
  const v0=y/t*Math.PI,v1=(y+1)/t*Math.PI,u0=x/s*2*Math.PI,u1=(x+1)/s*2*Math.PI;
  const f=(u,v)=>[Math.sin(v)*Math.cos(u),Math.cos(v),Math.sin(v)*Math.sin(u)];const p=[f(u0,v0),f(u1,v0),f(u1,v1),f(u0,v1)];
  for(const i of [0,2,1,0,3,2])vertex(a,p[i],p[i]);
 }return new Float32Array(a);}
function makeTexture(img,srgb){const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,srgb?gl.SRGB8_ALPHA8:gl.RGBA8,gl.RGBA,gl.UNSIGNED_BYTE,img);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);gl.generateMipmap(gl.TEXTURE_2D);return tex;}
async function image(url){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('Unable to load '+url));im.src=url;});}
function dynamicTexture(w,h){const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);
 gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,w,h,0,gl.RGBA,gl.FLOAT,null);
 for(const [p,v] of [[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);return tex;}
function setTexture(idx,tex){gl.activeTexture(gl.TEXTURE0+idx);gl.bindTexture(gl.TEXTURE_2D,tex);}
function syncWater(){if(!textures.film)return;
 gl.bindTexture(gl.TEXTURE_2D,textures.film);gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,fluid.fw,fluid.fh,gl.RGBA,gl.FLOAT,fluid.getFilmTexture());
 updateMesh(waterMesh,generateWater());}
function createTarget(w,h){const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,w,h,0,gl.RGBA,gl.HALF_FLOAT,null);
 for(const [p,v] of [[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);return tex;}
function setTargets(){let scale=S.scale;const dpr=Math.min(window.devicePixelRatio||1,1.5);const fullW=Math.floor(window.innerWidth*dpr),fullH=Math.floor(window.innerHeight*dpr);
 const w=Math.max(160,Math.round(fullW*scale)),h=Math.max(100,Math.round(fullH*scale));
 canvas.width=fullW;canvas.height=fullH;el('pixels').textContent=`${w} × ${h}`;el('actualScale').textContent=Math.round(scale*100)+'%';
 if(w===internalW&&h===internalH)return;
 internalW=w;internalH=h;
 if(opaqueFB){gl.deleteFramebuffer(opaqueFB);gl.deleteFramebuffer(compositeFB);gl.deleteTexture(opaqueTex);gl.deleteTexture(compositeTex);gl.deleteRenderbuffer(depthRbo);}
 opaqueTex=createTarget(w,h);compositeTex=createTarget(w,h);
 depthRbo=gl.createRenderbuffer();gl.bindRenderbuffer(gl.RENDERBUFFER,depthRbo);gl.renderbufferStorage(gl.RENDERBUFFER,gl.DEPTH_COMPONENT24,w,h);
 const frame=(tex)=>{const f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
 gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depthRbo);
 if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Game renderer target incomplete');return f;};
 opaqueFB=frame(opaqueTex);compositeFB=frame(compositeTex);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
}
function initShadow(){depthMaps=[];depthFB=[];for(let i=0;i<3;i++){
 const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,1024,1024,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
 for(const [p,v] of [[gl.TEXTURE_MIN_FILTER,gl.NEAREST],[gl.TEXTURE_MAG_FILTER,gl.NEAREST],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);
 const fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,tex,0);
 gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Shadow framebuffer incomplete');
 depthMaps.push(tex);depthFB.push(fb);}
 gl.bindFramebuffer(gl.FRAMEBUFFER,null);}
const lightPos=[[-.92,3.173,.08],[.92,3.173,.08],[-.557,1.221,-.110],[0,1.85,.7]];
const lightColor=[[9.1,10.1,12],[9.1,10.1,12],[9.2,5.3,2.3],[4,4.8,6]];
function shadowMatrix(i){const target=i===2?[-.55,.73,-.02]:[lightPos[i][0]*.15,.5,0];return mm(perspective(i===2?128:105,1,.04,7),lookAt(lightPos[i],target));}
function camera(){const {yaw,pitch,dist,target}=S;const eye=plus(target,[dist*Math.sin(yaw)*Math.cos(pitch),dist*Math.sin(pitch),dist*Math.cos(yaw)*Math.cos(pitch)]);
 return{eye,vp:mm(perspective(48,internalW/internalH,.035,60),lookAt(eye,target))};}
function bindMesh(m){gl.bindVertexArray(m.vao);}
function setUniformMat(p,u,name,val){if(u[name]!==undefined&&u[name]!==null)gl.uniformMatrix4fv(u[name],false,val);}
function setUniforms(p,view,camPos,model=identity(),mId=0){const u=uniforms[p];gl.useProgram(programs[p]);
 setUniformMat(p,u,'uViewProj',view);setUniformMat(p,u,'uModel',model);
 if(u.uCamera!==undefined&&u.uCamera!==null)gl.uniform3fv(u.uCamera,camPos);
 if(u.uMaterialType!==undefined&&u.uMaterialType!==null)gl.uniform1i(u.uMaterialType,mId);
 if(u.uMatId!==undefined&&u.uMatId!==null)gl.uniform1i(u.uMatId,mId);
 if(u.uMatA!==undefined&&u.uMatA!==null)gl.uniform4fv(u.uMatA,matA);
 if(u.uMatB!==undefined&&u.uMatB!==null)gl.uniform4fv(u.uMatB,matB);
 if(u.uShadowMatrices!==undefined&&u.uShadowMatrices!==null)gl.uniformMatrix4fv(u.uShadowMatrices,false,new Float32Array(shadowMatrices.flatMap(a=>Array.from(a))));
 if(u.uLightPos!==undefined&&u.uLightPos!==null)gl.uniform3fv(u.uLightPos,new Float32Array([...lightPos[0],...lightPos[1],...lightPos[2],...S.orbPos]));
 if(u.uLightRGB!==undefined&&u.uLightRGB!==null)gl.uniform3fv(u.uLightRGB,new Float32Array([...lightColor[0],...lightColor[1],...lightColor[2],...lightColor[3].map(x=>x*S.orbPower/100)]));
 if(u.uLightControls!==undefined&&u.uLightControls!==null)gl.uniform4fv(u.uLightControls,new Float32Array([S.room?1:0,S.room?1:0,S.lamp?1:0,S.orb?1:0]));
 if(u.uShadowSamples!==undefined&&u.uShadowSamples!==null)gl.uniform1i(u.uShadowSamples,S.shadowSamples);
 if(u.uViewport!==undefined&&u.uViewport!==null)gl.uniform2f(u.uViewport,internalW,internalH);
 if(u.uWaterIor!==undefined&&u.uWaterIor!==null)gl.uniform1f(u.uWaterIor,fluid.P.nWater);
 if(u.uExposure!==undefined&&u.uExposure!==null)gl.uniform1f(u.uExposure,S.exposure);
}
let matA,matB;
function shadowPass(){if(!shadowDirty)return;
 const p='depth';gl.useProgram(programs[p]);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.disable(gl.BLEND);
 for(let i=0;i<3;i++){gl.bindFramebuffer(gl.FRAMEBUFFER,depthFB[i]);gl.viewport(0,0,1024,1024);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);
  shadowMatrices[i]=shadowMatrix(i);setUniforms(p,shadowMatrices[i],lightPos[i]);bindMesh(mesh);
  for(const b of opaqueBatches){gl.drawArrays(gl.TRIANGLES,b.start,b.count);}
 }gl.bindFramebuffer(gl.FRAMEBUFFER,null);shadowDirty=false;}
function drawOpaque(vp,eye){gl.bindFramebuffer(gl.FRAMEBUFFER,opaqueFB);gl.viewport(0,0,internalW,internalH);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.disable(gl.BLEND);
 gl.clearColor(0,0,0,1);gl.clearDepth(1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 setUniforms('opaque',vp,eye);const u=uniforms.opaque;
 for(const [n,idx,tex] of [['uDeskColor',0,textures.deskColor],['uDeskRough',1,textures.deskRough],['uDeskNormal',9,textures.deskNormal],['uBrassColor',2,textures.brassColor],['uBrassRough',3,textures.brassRough],['uShadow0',4,depthMaps[0]],['uShadow1',5,depthMaps[1]],['uShadow2',6,depthMaps[2]]]){setTexture(idx,tex);if(u[n]!=null)gl.uniform1i(u[n],idx);}
 bindMesh(mesh);for(const b of opaqueBatches){gl.uniform1i(u.uMatId,b.material);gl.drawArrays(gl.TRIANGLES,b.start,b.count);}
 // Color of the actual glowing bulbs comes from the source emission, not fake ambient fill.
 gl.useProgram(programs.emissive);let ue=uniforms.emissive;setUniformMat('emissive',ue,'uViewProj',vp);
 bindMesh(sphereMesh);
 function drawSphere(pos,rad,col){const m=TRS(pos);m[0]*=rad;m[1]*=rad;m[2]*=rad;m[4]*=rad;m[5]*=rad;m[6]*=rad;m[8]*=rad;m[9]*=rad;m[10]*=rad;setUniformMat('emissive',ue,'uModel',m);gl.uniform3fv(ue.uColor,col);gl.drawArrays(gl.TRIANGLES,0,sphereMesh.count);}
 if(S.lamp)drawSphere(lightPos[2],.032,[7,3.8,1.6]);if(S.orb)drawSphere(S.orbPos,.044,lightColor[3].map(c=>c*S.orbPower/30));
}
function transparent(vp,eye){gl.bindFramebuffer(gl.READ_FRAMEBUFFER,opaqueFB);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,compositeFB);
 gl.blitFramebuffer(0,0,internalW,internalH,0,0,internalW,internalH,gl.COLOR_BUFFER_BIT,gl.NEAREST);
 gl.bindFramebuffer(gl.FRAMEBUFFER,compositeFB);gl.viewport(0,0,internalW,internalH);gl.enable(gl.DEPTH_TEST);gl.depthMask(false);gl.disable(gl.BLEND);
 setUniforms('transparent',vp,eye);const u=uniforms.transparent;
 setTexture(7,opaqueTex);gl.uniform1i(u.uOpaque,7);setTexture(8,textures.film);gl.uniform1i(u.uFilm,8);
 // Lamp shade is its original imported mesh; no substitute shape.
 bindMesh(mesh);setUniformMat('transparent',u,'uModel',identity());gl.uniform1i(u.uMaterialType,0);
 for(const b of glassBatches)gl.drawArrays(gl.TRIANGLES,b.start,b.count);
 if(S.water){const model=TRS(fluid.cupPos,...fluid.angles);
  // Film draw starts as actual zero-volume surface: dry pixels discarded.
  if(fluid.filmVolume()>1e-10){gl.useProgram(programs.film);const uf=uniforms.film;
   setUniforms('film',vp,eye,identity(),3);setTexture(7,opaqueTex);setTexture(8,textures.film);gl.uniform1i(uf.uOpaque,7);gl.uniform1i(uf.uFilm,8);
   bindMesh(filmMesh);gl.drawArrays(gl.TRIANGLES,0,filmMesh.count);}
  setUniforms('transparent',vp,eye,model,1);gl.uniform1i(u.uOpaque,7);gl.uniform1i(u.uFilm,8);
  bindMesh(cupMesh);gl.drawArrays(gl.TRIANGLES,0,cupMesh.count);
  gl.uniform1i(u.uMaterialType,2);bindMesh(waterMesh);gl.drawArrays(gl.TRIANGLES,0,waterMesh.count);
  // Each airborne parcel preserves exactly the physically simulated water volume.
  gl.uniform1i(u.uMaterialType,4);bindMesh(sphereMesh);
  for(const d of fluid.drops){const r=Math.cbrt(d.v*3/(4*Math.PI));const m=TRS(d.p);m[0]*=r;m[1]*=r;m[2]*=r;m[4]*=r;m[5]*=r;m[6]*=r;m[8]*=r;m[9]*=r;m[10]*=r;
   setUniformMat('transparent',u,'uModel',m);gl.drawArrays(gl.TRIANGLES,0,sphereMesh.count);}
 }
 gl.depthMask(true);
}
function display(){gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);
 gl.useProgram(programs.display);gl.bindVertexArray(quadVAO);setTexture(0,compositeTex);const u=uniforms.display;gl.uniform1i(u.uImage,0);gl.uniform1f(u.uExposure,S.exposure);gl.drawArrays(gl.TRIANGLES,0,6);}
function updateStats(t,deltaMs){fpsFrames++;if(!fpsWindow)fpsWindow=t;
 if(t-fpsWindow>=900){S.fps=fpsFrames*1000/(t-fpsWindow);S.frameTime=1000/S.fps;el('fps').textContent=S.fps.toFixed(1);el('frameMs').textContent=S.frameTime.toFixed(1)+' ms';
 el('fluidHz').textContent=S.water&&!fluid.paused?'up to 60 Hz':'OFF / PAUSED';fpsFrames=0;fpsWindow=t;
 if(S.adaptive){const goal=60,next=S.fps<goal*.86?Math.max(.58,S.scale-.05):S.fps>goal*1.12?Math.min(1,S.scale+.05):S.scale;
  if(Math.abs(next-S.scale)>.0001){S.scale=next;el('scale').value=Math.round(next*100);el('scaleValue').textContent=Math.round(next*100)+'%';setTargets();}}
 }
 if(benchmarking){if(deltaMs>0)benchFrames.push(deltaMs);if(t-benchStart>6000){benchmarking=false;const avg=benchFrames.reduce((x,y)=>x+y,0)/benchFrames.length;
 el('benchmarkOut').textContent=`Benchmark complete: ${S.fps.toFixed(1)} FPS currently (${avg.toFixed(1)} ms/frame). Mode: ${S.mode}, ${internalW}×${internalH}. Values are display-loop estimates; use GPU profiler for exact GPU time.`;
 }}
}
function waterStats(){const l=fluid.ledger(),m=x=>(x*1e6).toFixed(2)+' mL';for(const [k,v] of [['initial',l.initial],['cupVol',l.cup],['deskVol',l.desk],['flightVol',l.flight],['floorVol',l.floor]])el(k).textContent=m(v);
 el('massError').textContent=(l.error*1e6).toExponential(2)+' mL';}
function frame(t){try{const rawDelta=Math.max(0,t-(S.lastNow||t));const dt=Math.min(.033,rawDelta/1000);S.lastNow=t;
 if(S.water&&!fluid.paused){fluid.step(dt);fluidSeconds+=dt;if(t-lastWaterDraw>45){syncWater();lastWaterDraw=t;}}
 shadowPass();const c=camera();drawOpaque(c.vp,c.eye);transparent(c.vp,c.eye);display();updateStats(t,rawDelta);
 if(S.water&&S.frames%15===0)waterStats();S.frames++;raf=requestAnimationFrame(frame);
 }catch(e){fail(e);cancelAnimationFrame(raf);}}
function setMode(m){S.mode=m;for(const b of document.querySelectorAll('[data-mode]'))b.classList.toggle('selected',b.dataset.mode===m);
 S.shadowSamples=m==='speed'?1:4;S.scale=m==='quality'?1:m==='balanced'?.85:.65;
 el('scale').value=Math.round(S.scale*100);el('scaleValue').textContent=Math.round(S.scale*100)+'%';setTargets();}
function focusRoom(){S.dist=3.6;S.yaw=.60;S.pitch=.29;S.target=[0,.8,-.04];S.cupFocused=false;}
function focusCup(){S.dist=.78;S.yaw=.65;S.pitch=.38;S.target=[-.08,.82,.26];S.cupFocused=true;}
function bindControls(){const redrawLight=()=>{shadowDirty=true;};
 el('room').onchange=e=>{S.room=e.target.checked;redrawLight();};el('lamp').onchange=e=>{S.lamp=e.target.checked;redrawLight();};el('orb').onchange=e=>{S.orb=e.target.checked;redrawLight();};
 el('power').oninput=e=>{S.orbPower=+e.target.value;el('powerValue').textContent=S.orbPower+'%';};
 for(const [id,j] of [['orbX',0],['orbY',1],['orbZ',2]])el(id).onchange=e=>{S.orbPos[j]=+e.target.value;};
 el('lampOnly').onclick=()=>{S.room=false;S.lamp=true;S.orb=false;for(const [id,v] of [['room',false],['lamp',true],['orb',false]])el(id).checked=v;redrawLight();};
 el('allLights').onclick=()=>{S.room=true;S.lamp=true;S.orb=false;for(const [id,v] of [['room',true],['lamp',true],['orb',false]])el(id).checked=v;redrawLight();};
 for(const b of document.querySelectorAll('[data-mode]'))b.onclick=()=>setMode(b.dataset.mode);
 el('scale').oninput=e=>{S.scale=+e.target.value/100;el('scaleValue').textContent=e.target.value+'%';setTargets();};
 el('adaptive').onchange=e=>S.adaptive=e.target.checked;
 el('exposure').oninput=e=>{S.exposure=+e.target.value/100;el('exposureValue').textContent=S.exposure.toFixed(2)+'×';};
 function setWater(on){S.water=on;el('water').checked=on;el('waterTop').textContent='WATER: '+(on?'ON':'OFF');el('waterTop').classList.toggle('selected',on);waterStats();}
 el('water').onchange=e=>setWater(e.target.checked);el('waterTop').onclick=()=>setWater(!S.water);
 function pose(){fluid.setPose(+el('cupX').value,+el('cupZ').value,+el('tx').value*Math.PI/180,+el('tz').value*Math.PI/180,1/60);syncWater();}
 for(const id of ['cupX','cupZ','tx','tz'])el(id).oninput=()=>{el('txv').textContent=el('tx').value+'°';el('tzv').textContent=el('tz').value+'°';pose();};
 el('spill').onclick=()=>{setWater(true);el('tx').value=35;el('txv').textContent='35°';pose();};
 el('level').onclick=()=>{el('tx').value=0;el('tz').value=0;el('txv').textContent='0°';el('tzv').textContent='0°';pose();};
 el('pause').onchange=e=>{fluid.paused=e.target.checked;};
 el('resetWater').onclick=()=>{fluid.reset();el('cupX').value=-.08;el('cupZ').value=.258;el('tx').value=el('tz').value=0;el('txv').textContent=el('tzv').textContent='0°';el('pause').checked=false;syncWater();waterStats();};
 el('viewRoom').onclick=focusRoom;el('viewCup').onclick=focusCup;
 el('benchmark').onclick=()=>{benchmarking=true;benchStart=performance.now();benchFrames=[];el('benchmarkOut').textContent='Benchmarking 6 seconds using current settings…';};
 el('shot').onclick=()=>{const a=document.createElement('a');a.download='LightLab_Gaming_v0.1_'+Date.now()+'.png';a.href=canvas.toDataURL('image/png');a.click();};
 canvas.onpointerdown=e=>{S.isDragging=true;S.prevX=e.clientX;S.prevY=e.clientY;canvas.setPointerCapture(e.pointerId);};
 canvas.onpointermove=e=>{if(!S.isDragging)return;const dx=e.clientX-S.prevX,dy=e.clientY-S.prevY;S.prevX=e.clientX;S.prevY=e.clientY;
 S.yaw-=dx*.005;S.pitch=clamp(S.pitch+dy*.004,-1.2,1.25);};
 canvas.onpointerup=()=>S.isDragging=false;canvas.onpointercancel=()=>S.isDragging=false;
 canvas.onwheel=e=>{e.preventDefault();S.dist=clamp(S.dist*Math.exp(e.deltaY*.0008),.32,10);};
 window.onresize=()=>setTargets();window.addEventListener('keydown',e=>{if(e.target instanceof HTMLInputElement)return;
 if(e.key.toLowerCase()==='w')setWater(!S.water);if(e.key.toLowerCase()==='r')focusRoom();});
}
async function init(){try{el('status').textContent='LOADING GEOMETRY';
 const [m,raw,dColor,dRough,dNormal,bColor,bRough]=await Promise.all([fetch('assets/mesh.json').then(r=>r.json()),fetch('assets/mesh.bin').then(r=>r.arrayBuffer()),
 image('assets/desk-color.webp'),image('assets/desk-roughness.webp'),image('assets/desk-normal.webp'),image('assets/brass-color.webp'),image('assets/brass-roughness.webp')]);
 info=m;const verts=new Float32Array(raw);if(verts.length/24!==m.triangles)throw Error('Mesh file does not match triangle metadata');
 mesh=bufferMesh(verts);ranges=m.batches;opaqueBatches=ranges.filter(x=>x.material!==4);glassBatches=ranges.filter(x=>x.material===4);
 matA=new Float32Array(m.materials.flatMap(x=>[...x.color,x.roughness]));matB=new Float32Array(m.materials.flatMap(x=>[x.metallic,x.transmission,x.emission,0]));
 textures.deskColor=makeTexture(dColor,true);textures.deskRough=makeTexture(dRough,false);textures.deskNormal=makeTexture(dNormal,false);textures.brassColor=makeTexture(bColor,true);textures.brassRough=makeTexture(bRough,false);
 textures.film=dynamicTexture(fluid.fw,fluid.fh);
 cupMesh=bufferMesh(generateCup());waterMesh=bufferMesh(generateWater(),gl.DYNAMIC_DRAW);filmMesh=bufferMesh(createFilmGrid());sphereMesh=bufferMesh(makeSphere());
 programs={opaque:prog(SH.meshVS,SH.opaqueFS),transparent:prog(SH.meshVS,SH.transparentFS),film:prog(SH.filmVS,SH.transparentFS),depth:prog(SH.depthVS,SH.depthFS),display:prog(SH.quadVS,SH.displayFS),emissive:prog(SH.meshVS,`#version 300 es\nprecision highp float;out vec4 fragColor;uniform vec3 uColor;void main(){fragColor=vec4(uColor,1.);}`)};
 for(const k of Object.keys(programs))uniforms[k]=uniformsFor(programs[k]);
 quadVAO=gl.createVertexArray();gl.bindVertexArray(quadVAO);const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);gl.bindVertexArray(null);
 initShadow();shadowMatrices=[shadowMatrix(0),shadowMatrix(1),shadowMatrix(2)];syncWater();bindControls();waterStats();setMode('balanced');el('status').textContent='GPU RASTER · GGX · SHADOW MAPS';
 gl.disable(gl.CULL_FACE);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);raf=requestAnimationFrame(frame);
 }catch(e){fail(e);}}
init();
