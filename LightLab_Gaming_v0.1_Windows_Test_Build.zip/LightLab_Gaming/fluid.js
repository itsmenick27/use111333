/* LightLab Water Prototype A: physically motivated, conservative depth-averaged
   sloshing and tabletop film, in SI units (metres / seconds / kilograms).
   This is NOT a full 3-D Navier-Stokes, two-phase air/water or molecular solver.
   A cell-centred shallow-water finite-volume update uses paired face fluxes;
   weir flux transfers an explicit fluid volume from the cup to ballistic parcels;
   impacted parcels transfer that same volume to a depth-averaged desk film.
   All reservoirs are included in the volume ledger. No particles are just deleted.
*/
'use strict';
(function(global){
const G=9.80665, PI=Math.PI;
const P={rho:998.2,mu:.001002,sigma:.07274,nWater:1.333,nGlass:1.52,
 innerRadius:.037,outerRadius:.040,innerHeight:.108,outerHeight:.112,baseThickness:.004,
 deskY:.767, N:40, filmNX:144,filmNZ:72, filmXmin:-1.08,filmXmax:1.08,filmZmin:-.507,filmZmax:.507};
const s=(v,a,b)=>Math.max(a,Math.min(b,v));
function l2(x,z){return Math.hypot(x,z);}
function rotate(v,rx,rz){const [x,y,z]=v;let cy=Math.cos(rx),sy=Math.sin(rx),cz=Math.cos(rz),sz=Math.sin(rz);const yy=cy*y-sy*z,zz=sy*y+cy*z;return[cz*x-sz*yy,sz*x+cz*yy,zz];}
function inverseRotate(v,rx,rz){const [x,y,z]=v;let cz=Math.cos(rz),sz=Math.sin(rz),cy=Math.cos(rx),sy=Math.sin(rx);const xx=cz*x+sz*y,yy=-sz*x+cz*y;return [xx,cy*yy+sy*z,-sy*yy+cy*z];}
class FluidStudy{
 constructor(){this.P=P;this.N=P.N;this.dx=2*P.innerRadius/P.N;this.cellArea=this.dx**2;const n=this.N*this.N;
  this.frac=new Float64Array(n);this.edge=new Uint8Array(n);this.count=0;
  for(let z=0;z<this.N;z++)for(let x=0;x<this.N;x++){
   const k=z*this.N+x;let hit=0;const ns=6;
   for(let j=0;j<ns;j++)for(let i=0;i<ns;i++){
    const xx=(-P.innerRadius+(x+(i+.5)/ns)*this.dx)/P.innerRadius;
    const zz=(-P.innerRadius+(z+(j+.5)/ns)*this.dx)/P.innerRadius;
    if(xx*xx+zz*zz<=1)hit++;
   }
   // Binary full cells retain an exactly well-balanced rest state with
   // flat water. Sub-cell cut faces would require face-open-area pressure
   // reconstruction; without that correction they generate spurious waves.
   this.frac[k]=(hit>=18)?1:0;this.count+=this.frac[k];
  }
  this.area=this.count*this.cellArea;
  for(let z=0;z<this.N;z++)for(let x=0;x<this.N;x++){
   const k=z*this.N+x;if(!this.frac[k])continue;
   if(x===0||z===0||x===this.N-1||z===this.N-1||![this.frac[k-1],this.frac[k+1],this.frac[k-this.N],this.frac[k+this.N]].every(Boolean))this.edge[k]=1;
  }
  this.fw=P.filmNX;this.fh=P.filmNZ;this.fdX=(P.filmXmax-P.filmXmin)/this.fw;this.fdZ=(P.filmZmax-P.filmZmin)/this.fh;
  this.reset();
 }
 reset(){const n=this.N*this.N;this.h=new Float64Array(n);this.qx=new Float64Array(n);this.qz=new Float64Array(n);
  for(let i=0;i<n;i++)if(this.frac[i])this.h[i]=P.innerHeight*.75;
  this.initialVolume=this.cupVolume();this.drops=[];this.film=new Float64Array(this.fw*this.fh);this.floorVolume=0;
  this.cupPos=[-.08,P.deskY+.001,.258];this.angles=[0,0];this.linearVelocity=[0,0,0];this.acceleration=[0,0,0];
  this.lastPos=[...this.cupPos];this.stepCount=0;this.playing=false;this.settledFrames=0;this.paused=false;this.prevTime=0;this.massDrift=0;this.spillTotal=0;
  return this;
 }
 cupVolume(){let total=0;for(let i=0;i<this.h.length;i++)total+=this.h[i]*this.frac[i]*this.cellArea;return total;}
 filmVolume(){let v=0;for(let i=0;i<this.film.length;i++)v+=this.film[i]*this.fdX*this.fdZ;return v;}
 dropVolume(){return this.drops.reduce((a,d)=>a+d.v,0);}
 ledger(){const cup=this.cupVolume(),flight=this.dropVolume(),desk=this.filmVolume(),floor=this.floorVolume;
  return{cup,flight,desk,floor,initial:this.initialVolume,total:cup+flight+desk+floor,error:cup+flight+desk+floor-this.initialVolume};
 }
 setPose(x,z,rx,rz,dt){const rxC=s(rx,-.90,.90),rzC=s(rz,-.90,.90);
  // The rigid cup is moved upward as it tips, avoiding penetration of the
  // desktop by the lower edge of its circular base.
  const baseRise=P.outerRadius*Math.sqrt(Math.max(0,1-Math.cos(rxC)**2*Math.cos(rzC)**2));
  const pos=[s(x,-.43,.43),P.deskY+.001+baseRise,s(z,-.30,.33)];
  const vel=pos.map((v,i)=>(v-this.cupPos[i])/Math.max(dt,1/1000));
  this.acceleration=vel.map((v,i)=>s((v-this.linearVelocity[i])/Math.max(dt,1/1000),-25,25));
  this.linearVelocity=vel;this.cupPos=pos;this.angles=[rxC,rzC];this.playing=true;this.settledFrames=0;
 }
 localToWorld(v){const p=rotate(v,...this.angles);return p.map((t,i)=>t+this.cupPos[i]);}
 gravLocal(){const grav=inverseRotate([0,-G,0],...this.angles);const accel=inverseRotate(this.acceleration,...this.angles);
   return [grav[0]-accel[0],grav[1]-accel[1],grav[2]-accel[2]];
 }
 // Conservative paired flux between adjacent fluid columns; Rusanov flux for 2-D Saint-Venant system.
 stepCup(dt){const n=this.N*this.N,N=this.N,dx=this.dx,area=this.cellArea;
  const acc=this.gravLocal(),g=s(-acc[1],2,G*2.5),h=this.h,qx=this.qx,qz=this.qz;
  const dh=new Float64Array(n),mx=new Float64Array(n),mz=new Float64Array(n);const faces=[];
  const outgoing=new Float64Array(n);
  function face(a,b,axis,openness){if(!openness)return;
   const hA=h[a],hB=h[b],uA=hA>1e-8?qx[a]/hA:0,uB=hB>1e-8?qx[b]/hB:0,vA=hA>1e-8?qz[a]/hA:0,vB=hB>1e-8?qz[b]/hB:0;
   const speed=Math.max((axis===0?Math.abs(uA):Math.abs(vA))+Math.sqrt(g*Math.max(0,hA)),(axis===0?Math.abs(uB):Math.abs(vB))+Math.sqrt(g*Math.max(0,hB)));
   let fm=.5*((axis===0?qx[a]+qx[b]:qz[a]+qz[b])-speed*(hB-hA));
   const fmx=axis===0?.5*(qx[a]*uA+.5*g*hA*hA+qx[b]*uB+.5*g*hB*hB-speed*(qx[b]-qx[a])):.5*(qx[a]*vA+qx[b]*vB-speed*(qx[b]-qx[a]));
   const fmz=axis===1?.5*(qz[a]*vA+.5*g*hA*hA+qz[b]*vB+.5*g*hB*hB-speed*(qz[b]-qz[a])):.5*(qz[a]*uA+qz[b]*uB-speed*(qz[b]-qz[a]));
   const scale=dt*dx*openness;
   fm*=scale;
   const f={a,b,m:fm,x:fmx*scale,z:fmz*scale};faces.push(f);
   if(fm>0)outgoing[a]+=fm;else outgoing[b]-=fm;
  }
  // Each interior face appears exactly once, making mass cancellation explicit.
  for(let z=0;z<N;z++)for(let x=0;x<N;x++){
   const k=z*N+x;if(!this.frac[k])continue;
   if(x+1<N&&this.frac[k+1])face(k,k+1,0,Math.min(this.frac[k],this.frac[k+1]));
   if(z+1<N&&this.frac[k+N])face(k,k+N,1,Math.min(this.frac[k],this.frac[k+N]));
  }
  const limiter=new Float64Array(n);
  for(let k=0;k<n;k++)if(this.frac[k])limiter[k]=Math.min(1,h[k]*this.frac[k]*area/(outgoing[k]+1e-18)*.998);
  for(const f of faces){const factor=f.m>=0?limiter[f.a]:limiter[f.b];const m=f.m*factor;
   dh[f.a]-=m;dh[f.b]+=m;mx[f.a]-=f.x*factor;mx[f.b]+=f.x*factor;mz[f.a]-=f.z*factor;mz[f.b]+=f.z*factor;
  }
  for(let z=0;z<N;z++)for(let x=0;x<N;x++){
   const k=z*N+x;if(!this.frac[k])continue;
   const A=this.frac[k]*area;
   const nextH=Math.max(0,h[k]+dh[k]/A);
   let xmom=qx[k]+mx[k]/A+nextH*acc[0]*dt;
   let zmom=qz[k]+mz[k]/A+nextH*acc[2]*dt;
   // Closed-wall pressure traction at the container boundary.
   // Add only missing-side pressure contributions; the interior face supplies the rest.
   const px=.5*g*h[k]*h[k]*dt*dx/A;
   if(x===0||!this.frac[k-1])xmom+=px;
   if(x===N-1||!this.frac[k+1])xmom-=px;
   if(z===0||!this.frac[k-N])zmom+=px;
   if(z===N-1||!this.frac[k+N])zmom-=px;
   if(nextH<1e-5){xmom=0;zmom=0;}
   // Resolved fluid momentum damping: linear wall drag model dependent on ν=μ/ρ,
   // water depth, and no-slip at the base. It is *not* a viscosity-free animation.
   const nu=P.mu/P.rho;
   const friction=Math.exp(-3*nu*dt/Math.max(nextH*nextH,1e-8));
   this.h[k]=nextH;this.qx[k]=s(xmom*friction,-.8,.8);this.qz[k]=s(zmom*friction,-.8,.8);
  }
  // Weir flux from boundary columns only; every removed volume is tracked as an airborne parcel.
  const C=.61*(2/3)*Math.sqrt(2*g);
  for(let z=0;z<N;z++)for(let x=0;x<N;x++){
   const k=z*N+x;if(!this.edge[k]||!this.frac[k])continue;
   const over=this.h[k]-P.innerHeight;
   if(over<=.0002)continue;
   const dist=l2(x+.5-N*.5,z+.5-N*.5)||1,rx=(x+.5-N*.5)/dist,rz=(z+.5-N*.5)/dist;
   // A boundary column covers approximately one radial rim segment.
   const q=C*dx*Math.pow(over,1.5),V=Math.min(this.h[k]*this.frac[k]*area*.15,q*dt);
   if(V<1e-11)continue;
   this.h[k]-=V/(this.frac[k]*area);
   const local=[rx*P.innerRadius,P.outerHeight,rz*P.innerRadius];
   const world=this.localToWorld(local);
   const speed=Math.sqrt(2*g*over);
   const out=rotate([rx*speed*.75,this.qx[k]/Math.max(this.h[k],.001)*.15,rz*speed*.75],...this.angles);
   this.emit(V,world,[out[0]+this.linearVelocity[0],out[1]+this.linearVelocity[1],out[2]+this.linearVelocity[2]]);
   this.spillTotal+=V;
  }
 }
 emit(volume,pos,vel){if(volume<=0)return;
  if(this.drops.length>=64){
   // Combine with nearest fluid parcel. This merges *represented mass*, rather than deleting it.
   let j=0,best=Infinity;
   for(let i=0;i<this.drops.length;i++){
    const d=this.drops[i];const q=(d.p[0]-pos[0])**2+(d.p[1]-pos[1])**2+(d.p[2]-pos[2])**2;
    if(q<best){best=q;j=i;}
   }
   const d=this.drops[j],combined=d.v+volume;
   for(let k=0;k<3;k++){d.p[k]=(d.p[k]*d.v+pos[k]*volume)/combined;d.vel[k]=(d.vel[k]*d.v+vel[k]*volume)/combined;}
   d.v=combined;return;
  }
  this.drops.push({v:volume,p:[...pos],vel:[...vel]});
 }
 deposit(volume,x,z){
  // Impact volume is deposited at the resolved collision point into its four
  // adjacent finite-volume cells.  This is a conservative bilinear
  // discretization of a point source, NOT an arbitrarily enlarged puddle.
  // Subsequent spreading is governed by the film transport solver.
  const fx=(x-P.filmXmin)/this.fdX-.5,fz=(z-P.filmZmin)/this.fdZ-.5;
  const cx=Math.floor(fx),cz=Math.floor(fz),tx=fx-cx,tz=fz-cz;
  let total=0;const parts=[];
  for(let dz=0;dz<=1;dz++)for(let dx=0;dx<=1;dx++){
    const xx=cx+dx,zz=cz+dz;
    if(xx<0||xx>=this.fw||zz<0||zz>=this.fh)continue;
    const weight=(dx?tx:1-tx)*(dz?tz:1-tz);
    if(weight<=0)continue;
    parts.push([zz*this.fw+xx,weight]);total+=weight;
  }
  if(total<=0){this.floorVolume+=volume;return;}
  for(const [idx,w] of parts)this.film[idx]+=volume*w/(total*this.fdX*this.fdZ);
 }
 stepDrops(dt){const survivors=[];
  for(const d of this.drops){d.vel[1]-=G*dt;
   for(let k=0;k<3;k++)d.p[k]+=d.vel[k]*dt;
   const radius=Math.cbrt(d.v*3/(4*PI));
   if(d.p[1]-radius<=P.deskY&&Math.abs(d.p[0])<=1.08&&Math.abs(d.p[2])<=.507){this.deposit(d.v,d.p[0],d.p[2]);continue;}
   if(d.p[1]<0){this.floorVolume+=d.v;continue;}
   survivors.push(d);
  }
  this.drops=survivors;
 }
 stepFilm(dt){const w=this.fw,h=this.fh,arr=this.film,area=this.fdX*this.fdZ;
  const next=new Float64Array(arr.length);const out=new Float64Array(arr.length),faces=[];
  // Depth-averaged thin-film lubrication flux; capillary/wetting contact-line hysteresis
  // and fine rivulets are NOT adequately resolved in this first prototype.
  function transfer(a,b,width,dist){const d=arr[a]-arr[b];if(Math.abs(d)<1e-8)return;
   const depth=Math.max(arr[a],arr[b]);
   const mobility=Math.pow(depth,3)*P.rho*G/(3*P.mu);
   const v=mobility*(d/dist)*width*dt;
   const from=v>0?a:b,to=v>0?b:a,amount=Math.abs(v);
   faces.push([from,to,amount]);out[from]+=amount;
  }
  for(let z=0;z<h;z++)for(let x=0;x<w;x++){
   const k=z*w+x;if(x+1<w)transfer(k,k+1,this.fdZ,this.fdX);if(z+1<h)transfer(k,k+w,this.fdX,this.fdZ);
  }
  const limit=new Float64Array(arr.length);
  for(let i=0;i<arr.length;i++)limit[i]=Math.min(1,arr[i]*area/(out[i]+1e-30));
  for(const [from,to,v] of faces){const moved=v*limit[from];next[from]-=moved;next[to]+=moved;}
  for(let i=0;i<arr.length;i++)arr[i]=Math.max(0,arr[i]+next[i]/area);
 }
 step(dt){if(this.paused)return;
  const target=Math.min(.04,Math.max(0,dt));
  // With h<=0.2m and dx≈1.85mm the gravity wave CFL cap is below 1 ms.
  let remaining=target,loops=0;
  while(remaining>1e-6&&loops++<100){
   let maxSpeed=0,maxDepth=0;
   for(let i=0;i<this.h.length;i++)if(this.frac[i]&&this.h[i]>1e-6){const h=this.h[i];maxDepth=Math.max(maxDepth,h);maxSpeed=Math.max(maxSpeed,Math.hypot(this.qx[i],this.qz[i])/h);}
   const safe=.3*this.dx/(Math.sqrt(G*Math.max(maxDepth,1e-6))+maxSpeed+.1);
   const sub=Math.min(remaining,safe,.0025);
   this.stepCup(sub);this.stepDrops(sub);remaining-=sub;this.stepCount++;
  }
  this.stepFilm(target);
  // User-imposed acceleration is transient. Constant pose retains gravity slope.
  this.acceleration=this.acceleration.map(x=>x*.82);this.linearVelocity=this.linearVelocity.map(x=>x*.95);
  // Once the fully resolved state is quiescent, stop repeatedly invalidating
  // stochastic light accumulation. These thresholds are smaller than the
  // solver's 1.85 mm water grid. Do NOT sleep while droplets/puddles move.
  let minH=Infinity,maxH=0,maxSpeed=0;
  for(let i=0;i<this.h.length;i++)if(this.frac[i]){
    const d=this.h[i];minH=Math.min(minH,d);maxH=Math.max(maxH,d);
    if(d>1e-6)maxSpeed=Math.max(maxSpeed,Math.hypot(this.qx[i],this.qz[i])/d);
  }
  const stationary=Math.abs(this.angles[0])<.006&&Math.abs(this.angles[1])<.006&&
    maxH-minH<.00007&&maxSpeed<.001&&this.drops.length===0&&
    this.filmVolume()<1e-12&&Math.hypot(...this.linearVelocity)<.004;
  this.settledFrames=stationary?this.settledFrames+1:0;
  if(this.settledFrames>10){this.playing=false;this.linearVelocity=[0,0,0];this.acceleration=[0,0,0];}
  const l=this.ledger();this.massDrift=l.error;
 }
 getWaterTexture(){const v=new Float32Array(this.N*this.N*4);
  for(let i=0;i<this.h.length;i++){
   let h=this.h[i];
   if(!this.frac[i]){
    // Extend the free-surface height to nearby solid cells for bilinear
    // sampling. Interpolating against zero outside the cup would create an
    // artificial several-centimetre trench along the glass wall.
    const x=i%this.N,z=Math.floor(i/this.N);let best=1e9;
    for(let dz=-3;dz<=3;dz++)for(let dx=-3;dx<=3;dx++){
     const xx=x+dx,zz=z+dz;if(xx<0||xx>=this.N||zz<0||zz>=this.N)continue;
     const k=zz*this.N+xx,d=dx*dx+dz*dz;
     if(this.frac[k]&&d<best){best=d;h=this.h[k];}
    }
   }
   v[i*4]=h;v[i*4+1]=this.qx[i];v[i*4+2]=this.qz[i];v[i*4+3]=this.frac[i];
  }return v;
 }
 getFilmTexture(){const v=new Float32Array(this.film.length*4);for(let i=0;i<this.film.length;i++)v[i*4]=this.film[i];return v;}
 renderDrops(max=64){const a=new Float32Array(max*4);for(let i=0;i<Math.min(max,this.drops.length);i++){
   const d=this.drops[i];a.set([d.p[0],d.p[1],d.p[2],Math.cbrt(3*d.v/(4*PI))],4*i);
  }return a;}
}
global.LightLabFluid={FluidStudy,P,rotate,inverseRotate};
})(window);
