/* LightLab Gaming v0.1 custom WebGL2 shaders.
   GGX/Smith microfacets, Schlick Fresnel for opaque surfaces, inverse-square
   punctual sources, radiometric shadow tests. Fast raster rendering is NOT a
   reference solution for multi-bounce radiance or spectral caustics. */
window.LightLabGameShaders = {
  meshVS: `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPos;
  layout(location=1) in vec3 aNormal;
  layout(location=2) in vec2 aUv;
  uniform mat4 uViewProj,uModel;
  out vec3 vPos,vNormal; out vec2 vUv; out vec4 vLightSpace[3];
  uniform mat4 uShadowMatrices[3];
  void main(){ vec4 w=uModel*vec4(aPos,1.);vPos=w.xyz;vNormal=normalize(mat3(uModel)*aNormal);vUv=aUv;
    for(int i=0;i<3;i++)vLightSpace[i]=uShadowMatrices[i]*w;
    gl_Position=uViewProj*w; }
  `,
  depthVS: `#version 300 es
  precision highp float;layout(location=0)in vec3 aPos;
  uniform mat4 uViewProj,uModel;
  void main(){gl_Position=uViewProj*uModel*vec4(aPos,1.);}
  `,
  depthFS: `#version 300 es
  precision highp float;out vec4 outColor;void main(){outColor=vec4(1.);}
  `,
  opaqueFS: `#version 300 es
  precision highp float;
  #define PI 3.141592653589793
  in vec3 vPos,vNormal;in vec2 vUv;in vec4 vLightSpace[3];layout(location=0)out vec4 fragColor;
  uniform vec3 uCamera;uniform vec4 uMatA[22],uMatB[22];uniform int uMatId;
  uniform sampler2D uDeskColor,uDeskRough,uDeskNormal,uBrassColor,uBrassRough;
  uniform sampler2D uShadow0,uShadow1,uShadow2;
  uniform vec3 uLightPos[4],uLightRGB[4];uniform vec4 uLightControls;
  uniform int uShadowSamples;
  vec3 shadeBase(){vec3 b=uMatA[uMatId].rgb;
    if(uMatId==0){return max(texture(uDeskColor,vec2(vUv.x,1.-vUv.y)).rgb,vec3(.005));}
    if(uMatId==1||uMatId==3){vec2 uv=vPos.xz*3.1+vec2(vPos.y*.6,vPos.y*.3);return mix(b,texture(uBrassColor,uv).rgb,.26);}
    return b;}
  float roughness(){float r=uMatA[uMatId].a;
    if(uMatId==0)return clamp(mix(.26,.83,texture(uDeskRough,vec2(vUv.x,1.-vUv.y)).r),.09,.96);
    if(uMatId==1||uMatId==3){float t=texture(uBrassRough,vPos.xz*3.1+vec2(vPos.y*.6,vPos.y*.3)).r;return clamp(mix(r,.62,t*.32),.05,.7);}
    return r;}
  float shadowTex(int k,vec2 uv){if(k==0)return texture(uShadow0,uv).r;if(k==1)return texture(uShadow1,uv).r;return texture(uShadow2,uv).r;}
  float visibility(int idx,vec3 normal,vec3 dir){if(idx>=3)return 1.;vec4 q=vLightSpace[idx];if(q.w<=0.)return 1.;vec3 p=q.xyz/q.w*.5+.5;
    if(p.x<0.||p.x>1.||p.y<0.||p.y>1.||p.z<0.||p.z>1.)return 1.;
    float bias=max(.00015,.0012*(1.-max(dot(normal,dir),0.)));
    float sum=0.;const float stepS=1./1024.;
    if(uShadowSamples<=1){return p.z-bias<=shadowTex(idx,p.xy)?1.:0.;}
    for(int y=0;y<2;y++)for(int x=0;x<2;x++){
      vec2 offset=(vec2(float(x),float(y))-.5)*stepS*2.;sum+=p.z-bias<=shadowTex(idx,p.xy+offset)?1.:0.;}
    return sum*.25;}
  float Dggx(float nh,float a){float a2=a*a;float den=nh*nh*(a2-1.)+1.;return a2/max(1.e-7,PI*den*den);}
  float Smith(float nv,float a){float a2=a*a;return 2.*nv/max(1.e-6,nv+sqrt(a2+(1.-a2)*nv*nv));}
  vec3 Fschlick(vec3 f0,float hv){return f0+(1.-f0)*pow(1.-clamp(hv,0.,1.),5.);}
  vec3 lighting(vec3 base,float metal,float rough,vec3 N,vec3 V){
    float nv=max(dot(N,V),.0001);vec3 f0=mix(vec3(.04),base,metal);vec3 total=vec3(0.);
    for(int i=0;i<4;i++){if(uLightControls[i]<.5)continue;
      vec3 delta=uLightPos[i]-vPos;float dist2=max(dot(delta,delta),.001);vec3 L=delta*inversesqrt(dist2);
      float nl=max(dot(N,L),0.);if(nl<=0.)continue;
      vec3 H=normalize(V+L);float nh=max(dot(N,H),0.),vh=max(dot(V,H),0.);
      float a=max(.006,rough*rough);vec3 F=Fschlick(f0,vh);
      vec3 spec=F*(Dggx(nh,a)*Smith(nv,a)*Smith(nl,a)/(4.*nl*nv+1.e-6));
      vec3 diff=(1.-F)*(1.-metal)*base/PI;
      float vis=visibility(i,N,L);
      // Point-source approximation; watts/steradian are not yet calibrated.
      total+=(diff+spec)*nl*vis*uLightRGB[i]/dist2;
    }return total;}
  vec3 materialNormal(){vec3 N=normalize(vNormal);if(uMatId!=0)return N;
    vec2 d1=dFdx(vUv),d2=dFdy(vUv);
    float den=d1.x*d2.y-d2.x*d1.y;
    if(abs(den)<1.e-8)return N;
    vec3 p1=dFdx(vPos),p2=dFdy(vPos);
    vec3 T=normalize((p1*d2.y-p2*d1.y)/den),B=normalize((-p1*d2.x+p2*d1.x)/den);
    vec3 tnorm=texture(uDeskNormal,vec2(vUv.x,1.-vUv.y)).rgb*2.-1.;
    return normalize(T*tnorm.x-B*tnorm.y+N*tnorm.z);}
  void main(){vec3 base=shadeBase();float rough=roughness(),met=uMatB[uMatId].x;
    vec3 N=materialNormal(),V=normalize(uCamera-vPos);if(dot(N,V)<0.)N=-N;
    vec3 result=lighting(base,met,rough,N,V);
    fragColor=vec4(max(result,vec3(0.)),1.);
  }
  `,
  transparentFS: `#version 300 es
  precision highp float;
  #define PI 3.141592653589793
  in vec3 vPos,vNormal;in vec2 vUv;in vec4 vLightSpace[3];out vec4 fragColor;
  uniform int uMaterialType; // 0 lamp shade, 1 glass wall, 2 water surface, 3 film, 4 droplet
  uniform vec3 uCamera;uniform sampler2D uOpaque,uFilm;uniform vec2 uViewport;
  uniform vec3 uLightPos[4],uLightRGB[4];uniform vec4 uLightControls;
  uniform float uWaterIor;
  float Fresnel(float ci,float ei,float et){ci=clamp(abs(ci),0.,1.);float s2=(ei/et)*(ei/et)*(1.-ci*ci);
    if(s2>=1.)return 1.;float ct=sqrt(max(0.,1.-s2));float rs=(ei*ci-et*ct)/(ei*ci+et*ct),rp=(et*ci-ei*ct)/(et*ci+ei*ct);return .5*(rs*rs+rp*rp);}
  vec3 glassSpec(vec3 N,vec3 V,float F,float rough){vec3 c=vec3(0.);
    for(int i=0;i<4;i++){if(uLightControls[i]<.5)continue;
      vec3 d=uLightPos[i]-vPos;float dist2=max(dot(d,d),.001);vec3 L=normalize(d);float nl=max(dot(N,L),0.);
      if(nl<.00001)continue;vec3 H=normalize(V+L);float nh=max(dot(N,H),0.);
      float a=max(.006,rough*rough),a2=a*a;float dem=nh*nh*(a2-1.)+1.;float D=a2/(PI*dem*dem+1.e-7);
      float nv=max(dot(N,V),.001);float g1=2.*nv/(nv+sqrt(a2+(1.-a2)*nv*nv));float g2=2.*nl/(nl+sqrt(a2+(1.-a2)*nl*nl));
      c+=uLightRGB[i]*F*D*g1*g2/(4.*nv*dist2+.0001);
    }return c;}
  void main(){
    vec3 N=normalize(vNormal),V=normalize(uCamera-vPos);bool entering=dot(N,V)>0.;if(!entering)N=-N;
    float ior=uMaterialType==1||uMaterialType==0?1.52:uWaterIor;
    float etaI=entering?1.:ior,etaT=entering?ior:1.;
    float F=Fresnel(dot(N,V),etaI,etaT);
    float thickness=(uMaterialType==1?.003:uMaterialType==0?.003:uMaterialType==2?.075:uMaterialType==3?.0004:.006);
    if(uMaterialType==3){float filmDepth=texture(uFilm,clamp(vUv,0.,1.)).r;if(filmDepth<.000003)discard;thickness=filmDepth;}
    vec3 absorption=uMaterialType==0?vec3(180.,18.,110.):uMaterialType==1?vec3(.05,.03,.02):vec3(.21,.075,.023);
    // Beer–Lambert absorption through an estimated local path length.
    float pathLength=thickness/max(.15,abs(dot(N,V)));
    vec3 transmit=exp(-absorption*pathLength);
    vec3 refractDir=refract(-V,N,etaI/etaT);
    vec2 currentUV=gl_FragCoord.xy/uViewport;
    // Screen-space refraction: local-interface approximation, not a full second intersection.
    vec2 displaced=clamp(currentUV+refractDir.xy*thickness*.13,vec2(.002),vec2(.998));
    vec3 background=max(texture(uOpaque,displaced).rgb,vec3(0.));
    vec3 spec=glassSpec(N,V,F,uMaterialType==3?.045:.08);
    fragColor=vec4(background*transmit*(1.-F)+spec,1.);
  }
  `,
  filmVS: `#version 300 es
  precision highp float;layout(location=0)in vec3 aPos;layout(location=1)in vec3 aNormal;layout(location=2)in vec2 aUv;
  uniform mat4 uViewProj;uniform mat4 uShadowMatrices[3];uniform sampler2D uFilm;
  out vec3 vPos,vNormal;out vec2 vUv;out vec4 vLightSpace[3];
  void main(){float h=texture(uFilm,aUv).r;vPos=vec3(aPos.x,.767+.0005+h,aPos.z);
    vec2 t=vec2(1./144.,1./72.);float dx=(texture(uFilm,clamp(aUv+vec2(t.x,0.),0.,1.)).r-texture(uFilm,clamp(aUv-vec2(t.x,0.),0.,1.)).r)/(.03);
    float dz=(texture(uFilm,clamp(aUv+vec2(0.,t.y),0.,1.)).r-texture(uFilm,clamp(aUv-vec2(0.,t.y),0.,1.)).r)/(.03);
    vNormal=normalize(vec3(-dx,1.,-dz));vUv=aUv;
    vec4 w=vec4(vPos,1.);for(int i=0;i<3;i++)vLightSpace[i]=uShadowMatrices[i]*w;
    gl_Position=uViewProj*w;}
  `,
  quadVS:`#version 300 es
  precision highp float;layout(location=0)in vec2 aPos;out vec2 vUv;
  void main(){vUv=.5*aPos+.5;gl_Position=vec4(aPos,0.,1.);}
  `,
  displayFS:`#version 300 es
  precision highp float;in vec2 vUv;out vec4 outColor;uniform sampler2D uImage;uniform float uExposure;
  vec3 aces(vec3 c){return clamp((c*(2.51*c+.03))/(c*(2.43*c+.59)+.14),0.,1.);}
  vec3 srgb(vec3 x){return mix(12.92*x,1.055*pow(max(x,vec3(0.)),vec3(1./2.4))-.055,step(vec3(.0031308),x));}
  void main(){outColor=vec4(srgb(aces(max(texture(uImage,vUv).rgb,vec3(0.))*uExposure)),1.);}
  `
};
