@echo off
setlocal
cd /d "%~dp0"
echo Starting LightLab GAMING (separate from Scientific v1.5.1)...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-LightLab.ps1"
pause
