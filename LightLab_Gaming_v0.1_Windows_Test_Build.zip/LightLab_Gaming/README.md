# LightLab Gaming v0.1 — Standalone real-time experiment

**Status: first playable testing build; not an optically validated game renderer.**

This Gaming Edition is a separate application. It DOES NOT overwrite or modify LightLab Scientific v1.5.1. Its FBX-derived desk, banker lamp and ViewSonic 15-inch-class CRT geometry was repacked from the Scientific v1.5.1 model triangle data without altering the originals. Water-simulation calculations are reused from Scientific v1.5.1 but copied into this self-contained build.

## Windows launch

1. Extract the full ZIP.
2. Open `LightLab_Gaming` and double-click `Launch LightLab Gaming.bat`.
3. The included PowerShell server listens only on `127.0.0.1` with an ephemeral port, and opens your default browser. It does not connect to an external server.
4. Brave / Chrome must have graphics acceleration and WebGL2 enabled.
5. Close the PowerShell window to stop the local server.

If there is an initialization error, the UI will show the first exception or GLSL compilation error. You can also press F12 > Console for more detail.

## Controls

- **Quality**: full internal resolution, four shadow comparison taps. Target for still scene inspection. Not a path-tracing reference.
- **Balanced**: 85% internal render width/height, four shadow taps. Initial default.
- **Speed**: 65% internal render width/height, one shadow test. For performance triage.
- **Render scale**: override internal resolution independently. Display retains browser size.
- **Adaptive resolution**: optional adjustments of 5 percentage points based on measured display loop FPS; OFF by default.
- **Scene**: room ceiling lights, physically located desk lamp emitter, sphere intensity/location, preset light switches.
- **Cup + Water**: OFF by default for light comparisons. Turn ON, tilt with sliders or TILT 35°, let water spill and move as shallow water / airborne parcels / tabletop film. RESET restores the cup and all measured water.
- **Drag**: orbit camera; **wheel**: zoom. ROOM VIEW and CUP CLOSE-UP presets.
- **SAVE PNG**: saves a real-time raster image. Unlike Scientific's Render Capture, this does not accumulate thousands of paths.
- **BENCHMARK (6 SEC)**: records display frame intervals with the current scene and settings and reports FPS. It is not a GPU-only benchmark. Temperature is not available to a standard browser.

## Precisely what mathematics are used

- The opaque direct-light path uses microfacet Cook–Torrance shading (GGX normal distribution, Smith geometric masking, Fresnel–Schlick reflectance), energy partition between diffuse and specular, and inverse-square punctual light falloff.
- It draws the original 16,772 mesh triangles via indexed-by-batch WebGL2 raster vertex arrays.
- Opaque geometry depth is stored in three 1024px light-space depth maps, reused when the static room geometry and lamp arrangement do not change. Two or four manually compared texels approximate a filtered hard shadow edge, **not** the correct penumbra integration of an extended source.
- Transparent glass/water uses unpolarized Fresnel dielectric reflectance calculated from Snell's law, refractive index 1.52 (glass) / 1.333 (water), Beer–Lambert transmission, and a **limited screen-space refraction** sample of an opaque color buffer. It is not real multi-interface volumetric path tracing.
- The water mass ledger follows the same SI-unit conservative shallow-water grid (40×40), explicit volume transfer over the rim into ballistic droplets, and a 144×72 tabletop film grid from Scientific v1.5.1.
- No arbitrary ambient illumination or fake rainbow colors are injected. With all emitters off, the room is black (apart from UI).
- HDR buffers are tone mapped using a display-referred ACES approximation. Tone mapping is camera/display response, not simulated emitted light.

## Crucial limitations / scientific truth labels

1. **No full global illumination in Gaming v0.1.** Indirect multi-bounce radiation and refractive caustics require better approximations or separate reference calculations. This is why Gaming may look different from Scientific even at the same camera position.
2. **Real water motion is approximated** by conservative depth-averaged equations rather than full three-dimensional water–air Navier–Stokes. The model does not resolve every droplet, viscosity boundary layer, contact angle, complex turbulence, evaporation, or absorption into wood.
3. **Water refraction is screen-space** with a local-thickness approximation. Behind-foreground surfaces and multiple water/glass layers are not properly reconstructed. It does not deliver scientifically accurate caustics or dispersion.
4. **Water/cup do not cast refractive shadows** in the gaming build. Glass is excluded from opaque shadow maps to avoid false black occlusion. This intentionally omits real caustic shadows and dynamic water shadows; transparency lighting remains incomplete.
5. **Shadows approximate finite emitters as point sources.** They are deterministic and cheap but physically limited. Lighting power is still calibrated in relative scene units, not laboratory photometric measurements.
6. **The water film volume is numerically conserved, but subpixel wetting geometry is not resolved** and material data is unmeasured. Color and roughness are based on supplied textures and reasonable estimates, not certified measurements.
7. **No 60 FPS guarantee.** The user should run the included six-second benchmark on the actual GTX 1080, i9 and 32 GB Windows PC. Browser tests are blocked in the build environment, so actual WebGL2 execution on that device is still pending.
8. **Thermal-monitoring control is not implemented.** Standard browser pages cannot reliably read NVIDIA GPU temperature. Use Task Manager or a trusted GPU-monitoring program for thermal checks.

## Test workflow

1. Balanced, water OFF, overhead and lamp ON. Move camera; verify deterministic (non-sparkling) shadows and realistic light falloff.
2. Turn room OFF. Lamp ON should light nearby objects; physically omitted bounce light means distant areas may appear too dark.
3. Turn sphere ON and move its X/Y/Z coordinates to observe GGX highlights.
4. Turn cup ON, tilt 35°, watch conserved water move between the ledger columns, then reset.
5. Run BENCHMARK for six seconds in Quality, Balanced and Speed. Use render scale to find the highest feasible setting near 60 FPS.
6. SAVE PNG and compare with your v1.5.1 Scientific Render Capture. Differences reveal missing lighting physics, NOT a scientific accuracy percentage.

## Baseline preservation

The v1.5.1 Scientific application is not included in, overwritten by, or launched from Gaming. Keep both extracted in different folders.
